import React, { useState, useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { AuthContext } from '../components/login/AuthContext';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEye, faEyeSlash } from '@fortawesome/free-solid-svg-icons';

function Login() {
  const [values, setValues] = useState({
    email: '',
    password: ''
  });

  const [showPassword, setShowPassword] = useState(false);

  const { setIsAuthenticated, setUserEmail } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleSubmit = (event) => {
    event.preventDefault();
    axios.post('http://localhost:5000/login', values, { withCredentials: true })
      .then(res => {
        if (res.data.Status === "Success") {
          setIsAuthenticated(true);
          setUserEmail(values.email);
          localStorage.setItem('isAuthenticated', 'true');
          localStorage.setItem('userEmail', values.email);
          navigate('/');
        } else {
          alert("Error");
        }
      })
      .catch(err => console.log(err));
  };

  const toggleShowPassword = () => {
    setShowPassword(!showPassword);
  };

  return (
    <div style={styles.container}>
      <div style={styles.leftBox}>
        <h1 style={styles.appName}>Workdex™</h1>
      </div>
      <div style={styles.rightBox}>
        <div style={styles.formContainer}>
          <h2 style={styles.heading}>Sign-In</h2>
          <form onSubmit={handleSubmit}>
            <div style={styles.formGroup}>
              <label htmlFor="email" style={styles.label}><strong>Email</strong></label>
              <input
                type="email"
                placeholder="Enter Email"
                name='email'
                onChange={e => setValues({ ...values, email: e.target.value })}
                style={styles.input}
              />
            </div>
            <div style={styles.formGroup}>
              <label htmlFor="password" style={styles.label}><strong>Password</strong></label>
              <div style={styles.inputGroup}>
                <input
                  type={showPassword ? "text" : "password"}
                  placeholder="Enter Password"
                  name='password'
                  onChange={e => setValues({ ...values, password: e.target.value })}
                  style={styles.input}
                />
                <button 
                  type="button" 
                  onClick={toggleShowPassword}
                  style={styles.showPasswordButton}
                >
                  <FontAwesomeIcon icon={showPassword ? faEyeSlash : faEye} />
                </button>
              </div>
            </div>
            <button type='submit' style={styles.submitButton}>Log in</button>
            <p style={styles.text}>You agree to our terms and policies</p>
            <Link to="/register" style={styles.registerLink}>Create Account</Link>
          </form>
        </div>
      </div>
    </div>
  );
}

const styles = {
  container: {
    display: 'flex',
    height: '100vh',
    margin: 0,
  },
  leftBox: {
    flex: 1,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#0056b3',
    maxWidth: '50%',
  },
  rightBox: {
    flex: 1,
    maxWidth: '50%',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#007bff',
  },
  formContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
    padding: '2rem',
    borderRadius: '8px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    width: '300px',
    textAlign: 'center',
  },
  appName: {
    color: 'white',
    fontSize: '3rem',
    fontWeight: 'bold',
  },
  heading: {
    marginBottom: '1.5rem',
  },
  formGroup: {
    marginBottom: '1rem',
    textAlign: 'left',
  },
  label: {
    marginBottom: '.5rem',
    display: 'block',
  },
  input: {
    width: '100%',
    padding: '.5rem',
    borderRadius: '4px',
    border: '1px solid #ccc',
    boxSizing: 'border-box',
  },
  inputGroup: {
    position: 'relative',
  },
  showPasswordButton: {
    position: 'absolute',
    right: '10px',
    top: '50%',
    transform: 'translateY(-50%)',
    backgroundColor: 'transparent',
    border: 'none',
    cursor: 'pointer',
  },
  submitButton: {
    width: '100%',
    padding: '.75rem',
    backgroundColor: '#28a745',
    color: 'white',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
    marginBottom: '1rem',
  },
  text: {
    fontSize: '0.9rem',
    color: '#555',
    marginBottom: '1rem',
  },
  registerLink: {
    display: 'inline-block',
    width: '100%',
    padding: '.75rem',
    backgroundColor: '#f8f9fa',
    color: '#007bff',
    borderRadius: '4px',
    textDecoration: 'none',
    textAlign: 'center',
  },
};

export default Login;
