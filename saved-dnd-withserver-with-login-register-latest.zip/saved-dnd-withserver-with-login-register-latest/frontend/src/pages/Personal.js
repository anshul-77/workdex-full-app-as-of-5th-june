import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import ToDoList from '../components/to_do_list/ToDoList';
import InfoModal from '../components/personal/InfoModal';
import InfoModalCalendar from '../components/personal/InfoModalCalendar';
import InfoModalReadingList from '../components/personal/InfoModalReadingList';
import ReadingList from '../components/personal/ReadingList';
import { FaInfoCircle } from 'react-icons/fa';
import Sidebar from '../components/to_do_list/Sidebar';
import TopBar from '../components/notionmainpage/TopBar';

const Personal = () => {
  const [isTodoListOpen, setIsTodoListOpen] = useState(false);
  const [isInfoModalOpen, setIsInfoModalOpen] = useState(false);
  const [isInfoModalCalendarOpen, setIsInfoModalCalendarOpen] = useState(false);
  const [isInfoModalReadingListOpen, setIsInfoModalReadingListOpen] = useState(false);
  const [isReadingListOpen, setIsReadingListOpen] = useState(false);
  const [hoveredBox, setHoveredBox] = useState(null);

  const containerStyle = {
    display: 'flex',
    minHeight: '100vh',
  };

  const mainContentStyle = {
    flex: 1,
    padding: '20px',
    backgroundColor: '#f0f8ff',
    display: 'flex',
    flexDirection: 'column',
  };

  const contentInnerStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    gap: '40px', // Increased gap between the heading and the boxes
    flex: 1,
  };

  const boxContainerStyle = {
    display: 'flex',
    gap: '20px',
    flexWrap: 'wrap',
    justifyContent: 'center',
    flex: 1,
  };

  const todoListContainerStyle = {
    flex: '1',
    minWidth: '300px',
    backgroundColor: '#fff',
    padding: '20px',
    borderRadius: '12px',
    boxShadow: '0 4px 10px rgba(0, 0, 0, 0.1)',
    cursor: 'pointer',
    transition: 'transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out',
    textAlign: 'center',
    position: 'relative',
    overflow: 'hidden',
  };

  const todoListContainerHoverStyle = {
    transform: 'scale(1.05)',
    boxShadow: '0 8px 20px rgba(0, 0, 0, 0.2)',
  };

  const mainHeadingStyle = {
    fontFamily: 'cursive',
    fontSize: '2.5em',
    textAlign: 'center',
    color: '#1e90ff',
  };

  const infoIconStyle = {
    fontSize: '1.5em',
    color: '#1e90ff',
    cursor: 'pointer',
    marginTop: '10px',
  };

  const handleMouseEnter = (index) => {
    setHoveredBox(index);
  };

  const handleMouseLeave = () => {
    setHoveredBox(null);
  };

  const toggleTodoList = () => {
    setIsTodoListOpen((prev) => !prev);
  };

  const toggleReadingList = () => {
    setIsReadingListOpen((prev) => !prev);
  };

  const handleClose = () => {
    setIsTodoListOpen(false);
    setIsReadingListOpen(false);
  };

  const handleInfoIconClick = (e, type) => {
    e.stopPropagation();
    if (type === 'todo') {
      setIsInfoModalOpen(true);
    } else if (type === 'calendar') {
      setIsInfoModalCalendarOpen(true);
    } else if (type === 'reading') {
      setIsInfoModalReadingListOpen(true);
    }
  };

  const handleInfoModalClose = () => {
    setIsInfoModalOpen(false);
    setIsInfoModalCalendarOpen(false);
    setIsInfoModalReadingListOpen(false);
  };

  const overlayStyle = {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1000,
  };

  return (
    <div style={containerStyle}>
      <Sidebar />
      <div style={{ flex: 1 }}>
        <TopBar />
        <div style={mainContentStyle}>
          <div style={contentInnerStyle}>
            <h3 style={mainHeadingStyle}>Personal Lists</h3>
            <div style={boxContainerStyle}>
              <div
                style={{ ...todoListContainerStyle, ...(hoveredBox === 0 ? todoListContainerHoverStyle : {}) }}
                onClick={toggleTodoList}
                onMouseEnter={() => handleMouseEnter(0)}
                onMouseLeave={handleMouseLeave}
              >
                <h2 style={{ marginBottom: '10px', color: '#1e90ff' }}>Click to Open Todo List</h2>
                <p style={{ color: '#666' }}>Manage your tasks here</p>
                <FaInfoCircle
                  style={infoIconStyle}
                  onClick={(e) => handleInfoIconClick(e, 'todo')}
                />
              </div>

              <div
                style={{ ...todoListContainerStyle, ...(hoveredBox === 1 ? todoListContainerHoverStyle : {}) }}
                onMouseEnter={() => handleMouseEnter(1)}
                onMouseLeave={handleMouseLeave}
              >
                <Link to="/calendar" style={{ textDecoration: 'none', color: 'inherit' }}>
                  <h2 style={{ marginBottom: '10px', color: '#1e90ff' }}>Click to Open Event Calendar</h2>
                </Link>
                <p style={{ color: '#666' }}>View your calendar here</p>
                <FaInfoCircle
                  style={infoIconStyle}
                  onClick={(e) => handleInfoIconClick(e, 'calendar')}
                />
              </div>

              <div
                style={{ ...todoListContainerStyle, ...(hoveredBox === 2 ? todoListContainerHoverStyle : {}) }}
                onClick={toggleReadingList}
                onMouseEnter={() => handleMouseEnter(2)}
                onMouseLeave={handleMouseLeave}
              >
                <h2 style={{ marginBottom: '10px', color: '#1e90ff' }}>Click to Open Read List</h2>
                <p style={{ color: '#666' }}>Manage your read list here</p>
                <FaInfoCircle
                  style={infoIconStyle}
                  onClick={(e) => handleInfoIconClick(e, 'reading')}
                />
              </div>
            </div>
            {isTodoListOpen && <ToDoList onClose={handleClose} />}
            {isReadingListOpen && (
              <div style={overlayStyle}>
                <ReadingList onClose={handleClose} />
              </div>
            )}
            {isInfoModalOpen && <InfoModal onClose={handleInfoModalClose} />}
            {isInfoModalCalendarOpen && <InfoModalCalendar onClose={handleInfoModalClose} />}
            {isInfoModalReadingListOpen && <InfoModalReadingList onClose={handleInfoModalClose} />}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Personal;
