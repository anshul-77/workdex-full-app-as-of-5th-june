import React, { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import CardBoard from '../components/workspace/CardBoard';
import AddBoardForm from '../components/workspace/AddBoardForm';
import Sidebar from '../components/workspace/Sidebar';
import TopBar from '../components/workspace/TopBar';
import { AuthContext } from '../components/login/AuthContext';

const BoardContainer = () => {
  const [boards, setBoards] = useState([]);
  const [selectedBoardId, setSelectedBoardId] = useState(null);
  const [hoveredBoardId, setHoveredBoardId] = useState(null);
  const [hoveredButton, setHoveredButton] = useState(null);
  const [boardToDelete, setBoardToDelete] = useState(null);
  const [showBoards, setShowBoards] = useState(true);
  const { userEmail } = useContext(AuthContext);

  useEffect(() => {
    const fetchBoards = async () => {
      try {
        const response = await axios.get('http://localhost:5000/boards', {
          params: { email: userEmail } // Send the email as a query parameter
        });
        setBoards(response.data);
      } catch (error) {
        console.error('Error fetching boards:', error);
      }
    };

    fetchBoards();
  }, [userEmail]);

  const addBoard = async (boardName) => {
    try {
      const response = await axios.post('http://localhost:5000/boards', {
        name: boardName,
        email: userEmail // Include the email in the request
      });
      const newBoard = response.data;
      setBoards((prevBoards) => [...prevBoards, newBoard]);
    } catch (error) {
      console.error('Error adding board:', error);
    }
  };

  const confirmDeleteBoard = (boardId) => {
    setBoardToDelete(boardId);
  };

  const handleDeleteBoard = async () => {
    try {
      await axios.delete(`http://localhost:5000/boards/${boardToDelete}`);
      setBoards((prevBoards) => prevBoards.filter((board) => board.id !== boardToDelete));
      if (selectedBoardId === boardToDelete) {
        setSelectedBoardId(null);
      }
      setBoardToDelete(null);
    } catch (error) {
      console.error('Error deleting board:', error);
    }
  };

  const handleCancelDelete = () => {
    setBoardToDelete(null);
  };

  const handleBoardClick = (boardId) => {
    setSelectedBoardId(boardId);
  };

  const handleBackToBoards = () => {
    setSelectedBoardId(null);
  };

  const containerStyle = {
    display: 'flex',
    width: '100%',
    height: '100vh',
  };

  const mainContentAreaStyle = {
    display: 'flex',
    flexDirection: 'column',
    width: '100%',
  };

  const mainContentStyle = {
    flex: 1,
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    padding: '20px',
    boxSizing: 'border-box',
    overflowY: 'auto',
  };

  const handleToggleBoards = () => {
    setShowBoards((prevShowBoards) => !prevShowBoards);
  };

  return (
    <div style={containerStyle}>
      <Sidebar />
      <div style={mainContentAreaStyle}>
        <TopBar />
        <div style={mainContentStyle}>
          
          <h1 style={styles.heading}>Welcome to Your Workspace</h1>
          <br></br>
          <br></br>
          <br></br>
          <AddBoardForm addBoard={addBoard} />
          <button style={styles.toggleButton} onClick={handleToggleBoards}>
            {showBoards ? 'Hide Boards' : 'Show Boards'}
          </button>
          <br></br>
          {showBoards && selectedBoardId === null && (
            <div style={styles.boardsContainer}>
              {boards.map((board) => (
                <div
                  key={board.id}
                  style={{
                    ...styles.boardPreview,
                    ...(hoveredBoardId === board.id ? styles.boardPreviewHover : {}),
                  }}
                  onClick={() => handleBoardClick(board.id)}
                  onMouseEnter={() => setHoveredBoardId(board.id)}
                  onMouseLeave={() => setHoveredBoardId(null)}
                >
                  <p style={styles.boardName}>{board.name}</p>
                  <button
                    style={{
                      ...styles.deleteButton,
                      ...(hoveredButton === board.id ? styles.deleteButtonHover : {}),
                    }}
                    onClick={(e) => {
                      e.stopPropagation();
                      confirmDeleteBoard(board.id);
                    }}
                    onMouseEnter={() => setHoveredButton(board.id)}
                    onMouseLeave={() => setHoveredButton(null)}
                  >
                    &#x1F5D1; {/* Unicode for a trash can icon */}
                  </button>
                </div>
              ))}
            </div>
          )}
          {selectedBoardId !== null && (
            <div style={styles.boardContent}>
              <button
                onClick={handleBackToBoards}
                style={{
                  ...styles.backButton,
                  ...(hoveredButton === 'backButton' ? styles.backButtonHover : {}),
                }}
                onMouseEnter={() => setHoveredButton('backButton')}
                onMouseLeave={() => setHoveredButton(null)}
              >
                &#x2B05; {/* Unicode for a left arrow */}
              </button>
              <CardBoard boardId={selectedBoardId} onClose={handleBackToBoards} />
            </div>
          )}
          {boardToDelete && (
            <div style={styles.confirmationDialogOverlay}>
              <div style={styles.confirmationDialog}>
                <p>Are you sure you want to delete this board?</p>
                <div style={styles.confirmationButtons}>
                  <button style={styles.confirmButton} onClick={handleDeleteBoard}>Yes</button>
                  <button style={styles.cancelButton} onClick={handleCancelDelete}>No</button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const styles = {
  heading: {
    fontFamily: "'Arial', sans-serif",
    fontSize: '2em',
    color: '#333',
    marginBottom: '20px',
    padding: '10px',
    borderRadius: '8px',
    backgroundColor: '#f0f0f0',
    border: '2px solid #007bff',
    textAlign: 'center',
  },
  toggleButton: {
    margin: '20px',
    padding: '8px 16px',
    fontSize: '0.9em',
    backgroundColor: '#007bff',
    color: '#ffffff',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
    transition: 'background-color 0.2s',
  },
  boardsContainer: {
    display: 'flex',
    flexWrap: 'wrap',
    gap: '20px',
    width: '100%',
    maxWidth: '1200px',
    marginTop: '20px',
    justifyContent: 'center',
  },
  boardPreview: {
    width: '180px',
    height: '180px',
    padding: '10px',
    backgroundColor: '#ffffff',
    borderRadius: '12px',
    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    cursor: 'pointer',
    transition: 'transform 0.2s, box-shadow 0.2s, background-color 0.2s',
    textAlign: 'center',
    position: 'relative',
    overflow: 'hidden',
  },
  boardPreviewHover: {
    transform: 'scale(1.05)',
    boxShadow: '0 8px 16px rgba(0, 0, 0, 0.2)',
    backgroundColor: '#f0f0f0',
  },
  boardName: {
    margin: '0',
    fontSize: '1.2em',
    fontWeight: 'bold',
    color: '#333333',
    padding: '10px 0',
  },
  deleteButton: {
    position: 'absolute',
    top: '10px',
    right: '10px',
    backgroundColor: '#ff4d4d',
    color: '#ffffff',
    border: 'none',
    borderRadius: '4px',
    padding: '6px',
    cursor: 'pointer',
    fontSize: '0.8em',
    transition: 'background-color 0.2s',
  },
  deleteButtonHover: {
    backgroundColor: '#ff0000',
  },
  boardContent: {
    position: 'relative',
    width: '100%',
    height: '100%',
  },
  backButton: {
    position: 'absolute',
    top: '10px',
    left: '10px',
    padding: '8px 16px',
    backgroundColor: '#007bff',
    color: '#ffffff',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '0.9em',
    transition: 'background-color 0.2s',
    zIndex: 1,
  },
  backButtonHover: {
    backgroundColor: '#0056b3',
  },
  confirmationDialogOverlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    width: '100%',
    height: '100%',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 999,
  },
  confirmationDialog: {
    backgroundColor: '#ffffff',
    padding: '20px',
    borderRadius: '8px',
    textAlign: 'center',
    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
  },
  confirmationButtons: {
    display: 'flex',
    justifyContent: 'center',
    gap: '10px',
    marginTop: '10px',
  },
  confirmButton: {
    backgroundColor: '#ff4d4d',
    color: '#ffffff',
    border: 'none',
    borderRadius: '4px',
    padding: '8px 16px',
    cursor: 'pointer',
    fontSize: '0.9em',
  },
  cancelButton: {
    backgroundColor: '#007bff',
    color: '#ffffff',
    border: 'none',
    borderRadius: '4px',
    padding: '8px 16px',
    cursor: 'pointer',
    fontSize: '0.9em',
  },
};

export default BoardContainer;
