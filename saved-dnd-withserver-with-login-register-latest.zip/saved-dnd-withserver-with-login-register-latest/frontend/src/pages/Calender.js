import React, { useState, useEffect, Fragment, useContext } from 'react';
import axios from 'axios';
import { format, parseISO, addMonths, startOfMonth, endOfMonth, eachDayOfInterval } from 'date-fns';
import { AuthContext } from '../components/login/AuthContext'; // Import AuthContext
import TopBar from '../components/notionmainpage/TopBar';
import Sidebar from '../components/notionmainpage/Sidebar';

// Helper function to format date as YYYY-MM-DD in UTC
const formatDateUTC = (date) => {
  return format(date, 'yyyy-MM-dd');
};

const Calendar = () => {
  const { userEmail } = useContext(AuthContext);
  const [events, setEvents] = useState({});
  const [currentDate, setCurrentDate] = useState(new Date(2024, 5, 1)); // Start from June 2024
  const [selectedDate, setSelectedDate] = useState(null);
  const [isAddingEvent, setIsAddingEvent] = useState(false);

  useEffect(() => {
    fetchEvents();
  }, [currentDate, userEmail]);

  const fetchEvents = async () => {
    try {
      const response = await axios.get('http://localhost:5000/events', { params: { email: userEmail } });
      const eventsData = response.data.reduce((acc, event) => {
        const date = formatDateUTC(parseISO(event.date));
        if (!acc[date]) acc[date] = [];
        acc[date].push({ id: event.id, event: event.event });
        return acc;
      }, {});
      setEvents(eventsData);
    } catch (error) {
      console.error('Error fetching events:', error);
    }
  };

  const addEvent = async (date, event) => {
    try {
      const response = await axios.post('http://localhost:5000/events', { date: formatDateUTC(new Date(date)), event, email: userEmail });
      const eventId = response.data.id;
      setEvents((prevEvents) => ({
        ...prevEvents,
        [date]: [...(prevEvents[date] || []), { id: eventId, event }],
      }));
      setIsAddingEvent(false);
    } catch (error) {
      console.error('Error adding event:', error);
    }
  };

  const deleteEvent = async (date, eventId) => {
    try {
      await axios.delete(`http://localhost:5000/events/${eventId}`);
      setEvents((prevEvents) => ({
        ...prevEvents,
        [date]: prevEvents[date].filter(event => event.id !== eventId),
      }));
    } catch (error) {
      console.error('Error deleting event:', error);
    }
  };

  const changeMonth = (direction) => {
    setCurrentDate((prevDate) => {
      const newDate = addMonths(prevDate, direction);
      return newDate;
    });
  };

  const renderDays = () => {
    const days = [];
    const startDate = startOfMonth(currentDate);
    const endDate = endOfMonth(currentDate);
    const daysInMonth = eachDayOfInterval({ start: startDate, end: endDate });

    daysInMonth.forEach(day => {
      const date = formatDateUTC(day);
      days.push(
        <Day
          key={date}
          date={date}
          events={events[date]}
          isSelected={selectedDate === date}
          setSelectedDate={setSelectedDate}
          setIsAddingEvent={setIsAddingEvent}
        />
      );
    });

    return days;
  };

  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  return (
    <div>
      
      <TopBar /> {/* Add TopBar component here */}
      <div style={styles.calendarContainer}>
        <div style={styles.calendar}>
          <h2 style={styles.header}>My Personal Calendar</h2>
          <div style={styles.navBar}>
            <button onClick={() => changeMonth(-1)} style={styles.navButton}>{"<"}</button>
            <h3 style={styles.monthTitle}>{monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}</h3>
            <button onClick={() => changeMonth(1)} style={styles.navButton}>{">"}</button>
          </div>
          <div style={styles.daysContainer}>{renderDays()}</div>
        </div>
        {selectedDate && (
          <EventDetails
            date={selectedDate}
            events={events[selectedDate]}
            addEvent={addEvent}
            deleteEvent={deleteEvent}
            closeDetails={() => setSelectedDate(null)}
            isAddingEvent={isAddingEvent}
            setIsAddingEvent={setIsAddingEvent}
          />
        )}
      </div>
    </div>
  );
};

const Day = ({ date, events, isSelected, setSelectedDate, setIsAddingEvent }) => {
  return (
    <div
      style={{ ...styles.day, backgroundColor: isSelected ? '#b3e6ff' : '#0088cc' }}
      onClick={() => {
        setSelectedDate(date);
        setIsAddingEvent(false);
      }}
    >
      <div style={styles.date}>{date.split('-')[2]}</div>
      <div style={styles.eventsCount}>
        {events && events.length > 0 && `${events.length} event(s)`}
      </div>
    </div>
  );
};

const EventDetails = ({ date, events, addEvent, deleteEvent, closeDetails, isAddingEvent, setIsAddingEvent }) => {
  const [newEvent, setNewEvent] = useState('');

  const handleAddEvent = () => {
    if (newEvent) {
      addEvent(date, newEvent);
      setNewEvent('');
    }
  };

  return (
    <div style={styles.eventDetails}>
      <div style={styles.eventDetailsHeader}>
        <h3>Events for {date}</h3>
        <span style={styles.closeButton} onClick={closeDetails}>&times;</span>
      </div>
      <div style={styles.eventsList}>
        {events && events.map(({ id, event }) => (
          <div key={id} style={styles.eventDetail}>
            {event}
            <button
              onClick={() => deleteEvent(date, id)}
              style={styles.deleteButton}
            >
              Delete
            </button>
          </div>
        ))}
      </div>
      {isAddingEvent ? (
        <div style={styles.addEventForm}>
          <input
            type="text"
            value={newEvent}
            onChange={(e) => setNewEvent(e.target.value)}
            style={styles.eventInput}
          />
          <button onClick={handleAddEvent} style={styles.addEventButton}>Add</button>
        </div>
      ) : (
        <button onClick={() => setIsAddingEvent(true)} style={styles.addEventButton}>Add Event</button>
      )}
    </div>
  );
};

const styles = {
  calendarContainer: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    minHeight: '100vh',
    backgroundColor: '#e6f7ff',
  },
  calendar: {
    width: '80%',
    margin: '20px auto',
    textAlign: 'center',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    borderRadius: '10px',
    backgroundColor: '#fff',
    padding: '20px',
    backgroundColor: '#b3e6ff',
  },
  header: {
    fontSize: '2em',
    margin: '20px 0',
    color: '#0088cc',
  },
  navBar: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '20px',
    color: '#0088cc',
  },
  navButton: {
    fontSize: '1.5em',
    padding: '0 10px',
    cursor: 'pointer',
    background: 'none',
    border: 'none',
    outline: 'none',
    color: '#0088cc',
  },
  monthTitle: {
    flex: 1,
    textAlign: 'center',
  },
  daysContainer: {
    display: 'flex',
    flexWrap: 'wrap',
    justifyContent: 'center',
  },
  day: {
    border: '1px solid #ccc',
    borderRadius: '5px',
    width: '80px',
    height: '80px',
    margin: '5px',
    cursor: 'pointer',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    transition: 'background-color 0.3s',
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
  },
  date: {
    fontSize: '1.5em',
    fontWeight: 'bold',
  },
  eventsCount: {
    marginTop: '10px',
    fontSize: '0.8em',
    color: '#ffffff',
  },
  eventDetails: {
    position: 'fixed',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    backgroundColor: '#fff',
    border: '1px solid #ccc',
    borderRadius: '10px',
    padding: '20px',
    width: '300px',
    textAlign: 'center',
    zIndex: 1000,
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
  },
  eventDetailsHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '10px',
  },
  closeButton: {
    cursor: 'pointer',
    fontSize: '1.5em',
    fontWeight: 'bold',
    color: '#f44336',
  },
  eventsList: {
    maxHeight: '150px',
    overflowY: 'auto',
    marginBottom: '10px',
  },
  eventDetail: {
    padding: '5px 0',
    borderBottom: '1px solid #ccc',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  deleteButton: {
    marginLeft: '10px',
    cursor: 'pointer',
    padding: '2px 5px',
    border: 'none',
    borderRadius: '3px',
    backgroundColor: '#e53935',
    color: '#fff',
  },
  addEventButton: {
    cursor: 'pointer',
    padding: '5px 10px',
    border: 'none',
    borderRadius: '3px',
    backgroundColor: '#4caf50',
    color: '#fff',
  },
  addEventForm: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  eventInput: {
    marginBottom: '10px',
    padding: '5px',
    width: '100%',
    boxSizing: 'border-box',
  },
};

export default Calendar;
