import React, { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import TaskForm from '../components/gantchart/TaskForm';
import GanttChartView from '../components/gantchart/GanttChartView';
import PieChartModal from '../components/gantchart/PieChartModal';
import TopBar from '../components/notionmainpage/TopBar';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { AuthContext } from '../components/login/AuthContext';

ChartJS.register(ArcElement, Tooltip, Legend);

const DeleteDialog = ({ task, onConfirm, onCancel }) => {
  const dialogStyle = {
    position: 'fixed',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    backgroundColor: '#fff',
    padding: '20px',
    boxShadow: '0 2px 10px rgba(0,0,0,0.1)',
    borderRadius: '4px',
    zIndex: 1000,
  };

  const overlayStyle = {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.5)',
    zIndex: 999,
  };

  const buttonStyle = {
    padding: '5px 10px',
    cursor: 'pointer',
    border: 'none',
    borderRadius: '4px',
    margin: '0 5px',
  };

  return (
    <>
      <div style={overlayStyle} onClick={onCancel}></div>
      <div style={dialogStyle}>
        <p>Are you sure you want to delete the task "{task.title}"?</p>
        <button onClick={onConfirm} style={{ ...buttonStyle, backgroundColor: '#28a745', color: '#fff' }}>Confirm</button>
        <button onClick={onCancel} style={{ ...buttonStyle, backgroundColor: '#dc3545', color: '#fff' }}>Cancel</button>
      </div>
    </>
  );
};

const GanttChart = () => {
  const { userEmail } = useContext(AuthContext);
  const [tasks, setTasks] = useState([]);
  const [editTaskId, setEditTaskId] = useState(null);
  const [editedTask, setEditedTask] = useState({});
  const [showPieChart, setShowPieChart] = useState(false);
  const [deleteTaskId, setDeleteTaskId] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');

  const fetchTasks = async () => {
    try {
      const response = await axios.get(`http://localhost:5000/tasks?email=${userEmail}`);
      setTasks(response.data);
    } catch (error) {
      console.error('Error fetching tasks:', error);
    }
  };

  useEffect(() => {
    if (userEmail) {
      fetchTasks();
    }
  }, [userEmail]);

  const addTask = async (newTask) => {
    try {
      await axios.post('http://localhost:5000/tasks', { ...newTask, email: userEmail });
      fetchTasks();
    } catch (error) {
      console.error('Error adding task:', error);
    }
  };

  const deleteTask = async (taskId) => {
    try {
      await axios.delete(`http://localhost:5000/tasks/${taskId}`);
      fetchTasks();
      setDeleteTaskId(null);
    } catch (error) {
      console.error('Error deleting task:', error);
    }
  };

  const saveTask = async (taskId) => {
    try {
      await axios.put(`http://localhost:5000/tasks/${taskId}`, editedTask);
      fetchTasks();
      setEditTaskId(null);
    } catch (error) {
      console.error('Error saving task:', error);
    }
  };

  const handleEditClick = (task) => {
    setEditTaskId(task.id);
    setEditedTask(task);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditedTask({ ...editedTask, [name]: value });
  };

  const handleCancelEdit = () => {
    setEditTaskId(null);
    setEditedTask({});
  };

  const handleDeleteClick = (taskId) => {
    setDeleteTaskId(taskId);
  };

  const handleConfirmDelete = () => {
    deleteTask(deleteTaskId);
  };

  const handleCancelDelete = () => {
    setDeleteTaskId(null);
  };

  const togglePieChart = () => {
    setShowPieChart(!showPieChart);
  };

  const getPieChartData = () => {
    const completedTasks = tasks.filter(task => task.progress === 100).length;
    const inProgressTasks = tasks.filter(task => task.progress > 0 && task.progress < 100).length;
    const notStartedTasks = tasks.filter(task => task.progress === 0).length;

    return {
      labels: ['Completed', 'In Progress', 'Not Started'],
      datasets: [
        {
          label: 'Task Progress',
          data: [completedTasks, inProgressTasks, notStartedTasks],
          backgroundColor: ['#28a745', '#ffc107', '#dc3545'],
          hoverBackgroundColor: ['#218838', '#e0a800', '#c82333'],
        },
      ],
    };
  };

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
  };

  const containerStyle = {
    maxWidth: '1500px',
    margin: '0 auto',
    padding: '20px',
    fontFamily: 'Arial, sans-serif',
    backgroundColor: '#80bfff',
    borderRadius: '20px',
  };

  const headerStyle = {
    textAlign: 'center',
    marginBottom: '20px',
    fontFamily: "'Comic Sans MS', cursive, sans-serif",
    fontSize: '28px',
    fontWeight: 'bold',
    color: '#333',
    textTransform: 'uppercase',
  };

  const taskFormContainerStyle = {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'column',
  };

  const taskListContainerStyle = {
    marginTop: '30px',
  };

  const taskBoxStyle = {
    border: '1px solid #ccc',
    borderRadius: '4px',
    padding: '10px',
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
    color: '#fff',
  };

  const taskTableStyle = {
    width: '100%',
    borderCollapse: 'collapse',
    color: '#fff',
  };

  const taskTableHeaderStyle = {
    backgroundColor: 'rgba(0, 0, 0, 0.9)',
    color: '#fff',
  };

  const taskTableCellStyle = {
    border: '1px solid #ccc',
    padding: '10px',
    textAlign: 'center',
  };

  const inputStyle = {
    padding: '5px',
    width: '100%',
  };

  const taskButtonsStyle = {
    display: 'flex',
    justifyContent: 'center',
    gap: '10px',
  };

  const taskButtonStyle = {
    padding: '5px 10px',
    cursor: 'pointer',
    border: 'none',
    borderRadius: '4px',
  };

  const chartButtonContainerStyle = {
    display: 'flex',
    justifyContent: 'center',
    marginTop: '20px',
  };

  return (
    <div style={containerStyle}>
      <TopBar searchQuery={searchQuery} handleSearchChange={handleSearchChange} />
      <h1 style={headerStyle}>Gantt-Chart-Progress</h1>
      <div style={taskFormContainerStyle}>
        <TaskForm addTask={addTask} />
      </div>

      <div style={taskListContainerStyle}>
        <h2 style={headerStyle}>Task List</h2>
        <div style={taskBoxStyle}>
          <table style={taskTableStyle}>
            <thead style={taskTableHeaderStyle}>
              <tr>
                <th style={taskTableCellStyle}>Title</th>
                <th style={taskTableCellStyle}>Start Date</th>
                <th style={taskTableCellStyle}>End Date</th>
                <th style={taskTableCellStyle}>Progress</th>
                <th style={taskTableCellStyle}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {tasks.map(task => (
                <tr key={task.id}>
                  {editTaskId === task.id ? (
                    <>
                      <td style={taskTableCellStyle}>
                        <input
                          type="text"
                          name="title"
                          placeholder="Title"
                          value={editedTask.title || ''}
                          onChange={handleInputChange}
                          style={inputStyle}
                        />
                      </td>
                      <td style={taskTableCellStyle}>
                        <input
                          type="date"
                          name="start_date"
                          placeholder="Start Date"
                          value={editedTask.start_date || ''}
                          onChange={handleInputChange}
                          style={inputStyle}
                        />
                      </td>
                      <td style={taskTableCellStyle}>
                        <input
                          type="date"
                          name="end_date"
                          placeholder="End Date"
                          value={editedTask.end_date || ''}
                          onChange={handleInputChange}
                          style={inputStyle}
                        />
                      </td>
                      <td style={taskTableCellStyle}>
                        <input
                          type="number"
                          name="progress"
                          placeholder="Progress"
                          value={editedTask.progress || ''}
                          onChange={handleInputChange}
                          style={inputStyle}
                        />
                      </td>
                      <td style={taskTableCellStyle}>
                        <div style={taskButtonsStyle}>
                          <button onClick={() => saveTask(task.id)} style={{ ...taskButtonStyle, backgroundColor: '#28a745', color: '#fff' }}>Save</button>
                          <button onClick={handleCancelEdit} style={{ ...taskButtonStyle, backgroundColor: '#dc3545', color: '#fff' }}>Cancel</button>
                        </div>
                      </td>
                    </>
                  ) : (
                    <>
                      <td style={taskTableCellStyle}>{task.title}</td>
                      <td style={taskTableCellStyle}>{task.start_date}</td>
                      <td style={taskTableCellStyle}>{task.end_date}</td>
                      <td style={taskTableCellStyle}>Progress: {task.progress}%</td>
                      <td style={taskTableCellStyle}>
                        <div style={taskButtonsStyle}>
                          <button onClick={() => handleEditClick(task)} style={{ ...taskButtonStyle, backgroundColor: '#007bff', color: '#fff' }}>Edit</button>
                          <button onClick={() => handleDeleteClick(task.id)} style={{ ...taskButtonStyle, backgroundColor: '#dc3545', color: '#fff' }}>Delete</button>
                        </div>
                      </td>
                    </>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div>
        <br></br>
        <br></br>
        <GanttChartView tasks={tasks} />
      </div>

      <div style={chartButtonContainerStyle}>
        <button onClick={togglePieChart} style={{ ...taskButtonStyle, backgroundColor: '#17a2b8', color: '#fff', padding: '10px 20px' }}>
          {showPieChart ? 'Hide Pie Chart' : 'Show Pie Chart'}
        </button>
      </div>

      {showPieChart && (
        <PieChartModal data={getPieChartData()} onClose={togglePieChart} />
      )}

      {deleteTaskId && (
        <DeleteDialog
          task={tasks.find(task => task.id === deleteTaskId)}
          onConfirm={handleConfirmDelete}
          onCancel={handleCancelDelete}
        />
      )}
    </div>
  );
};

export default GanttChart;
