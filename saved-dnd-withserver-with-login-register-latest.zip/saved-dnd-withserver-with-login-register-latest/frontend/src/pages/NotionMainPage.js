import React, { useState } from 'react';
import Sidebar from '../components/notionmainpage/Sidebar';
import TopBar from '../components/notionmainpage/TopBar';
import MainContent from '../components/notionmainpage/MainContent';
import ChatbotComponent from '../components/chatbox/ChatbotComponent';

const NotionMainPage = () => {
  const notionMainPageStyle = {
    display: 'flex',
    position: 'relative',
    width: '100%',
    minHeight: '100vh', // Ensure the page takes full height of the viewport
  };

  const mainContentAreaStyle = {
    display: 'flex',
    flexDirection: 'column',
    width: '100%',
  };

  const [searchQuery, setSearchQuery] = useState('');
  const [showChatbot, setShowChatbot] = useState(false);

  const handleSearchChange = (event) => {
    setSearchQuery(event.target.value);
  };

  const toggleChatbot = () => {
    setShowChatbot(!showChatbot);
  };

  const closeChatbot = () => {
    setShowChatbot(false);
  };

  return (
    <div style={notionMainPageStyle}>
      <Sidebar />
      <div style={mainContentAreaStyle}>
        <TopBar
          searchQuery={searchQuery}
          handleSearchChange={handleSearchChange}
          toggleChatbot={toggleChatbot}
        />
        <MainContent searchQuery={searchQuery} />
      </div>
      {showChatbot && (
        <div style={{ position: 'fixed', bottom: '20px', left: '20px', zIndex: 1000 }}>
          <ChatbotComponent onClose={closeChatbot} />
        </div>
      )}
      {!showChatbot && (
        <button
          style={{
            position: 'fixed',
            bottom: '20px',
            left: '20px',
            backgroundColor: '#5ccc9d',
            color: '#ffffff',
            border: 'none',
            borderRadius: '10px',
            padding: '10px 20px',
            cursor: 'pointer',
            zIndex: 1000,
          }}
          onClick={toggleChatbot}
        >
          Ask Chatbot
        </button>
      )}
    </div>
  );
};

export default NotionMainPage;
