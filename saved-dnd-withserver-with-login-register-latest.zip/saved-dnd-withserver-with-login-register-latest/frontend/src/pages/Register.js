import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';

function Register() {
    const [values, setValues] = useState({
        name: '',
        email: '',
        password: ''
    });

    const navigate = useNavigate();

    const handleSubmit = (event) => {
        event.preventDefault();
        axios.post('http://localhost:5000/register', values)
            .then(res => {
                if (res.data.Status === "Success") {
                    navigate('/login');
                } else {
                    alert("Error");
                }
            })
            .catch(err => console.log(err));
    }

    return (
        <div style={styles.container}>
            <div style={styles.leftBox}>
                <h1 style={styles.appName}>Workdex™</h1>
            </div>
            <div style={styles.rightBox}>
                <div style={styles.formContainer}>
                    <h2 style={styles.heading}>Sign-Up</h2>
                    <form onSubmit={handleSubmit}>
                        <div style={styles.formGroup}>
                            <label htmlFor="name" style={styles.label}><strong>Name</strong></label>
                            <input
                                type="text"
                                placeholder="Enter Name"
                                name='name'
                                onChange={e => setValues({ ...values, name: e.target.value })}
                                style={styles.input}
                            />
                        </div>
                        <div style={styles.formGroup}>
                            <label htmlFor="email" style={styles.label}><strong>Email</strong></label>
                            <input
                                type="email"
                                placeholder="Enter Email"
                                name='email'
                                onChange={e => setValues({ ...values, email: e.target.value })}
                                style={styles.input}
                            />
                        </div>
                        <div style={styles.formGroup}>
                            <label htmlFor="password" style={styles.label}><strong>Password</strong></label>
                            <input
                                type="password"
                                placeholder="Enter Password"
                                name='password'
                                onChange={e => setValues({ ...values, password: e.target.value })}
                                style={styles.input}
                            />
                        </div>
                        <button type='submit' style={styles.submitButton}>Sign up</button>
                        <p style={styles.text}>You agree to our terms and policies</p>
                        <Link to="/login" style={styles.registerLink}>Back to Log-In</Link>
                    </form>
                </div>
            </div>
        </div>
    );
}

const styles = {
    container: {
        display: 'flex',
        height: '100vh',
        margin: 0,
    },
    leftBox: {
        flex: 1,
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#0056b3',
        maxWidth: '50%', // Ensure the left box is 50% width
    },
    rightBox: {
        flex: 1,
        maxWidth: '50%', // Ensure the right box is 50% width
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#007bff',
    },
    formContainer: {
        backgroundColor: 'rgba(255, 255, 255, 0.8)',
        padding: '2rem',
        borderRadius: '8px',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
        width: '300px', // Set a fixed width for the form container
        textAlign: 'center',
    },
    appName: {
        color: 'white',
        fontSize: '3rem',
        fontWeight: 'bold',
    },
    heading: {
        marginBottom: '1.5rem',
    },
    formGroup: {
        marginBottom: '1rem',
        textAlign: 'left',
    },
    label: {
        marginBottom: '.5rem',
        display: 'block',
    },
    input: {
        width: '100%',
        padding: '.5rem',
        borderRadius: '4px',
        border: '1px solid #ccc',
    },
    submitButton: {
        width: '100%',
        padding: '.75rem',
        backgroundColor: '#28a745',
        color: 'white',
        border: 'none',
        borderRadius: '4px',
        cursor: 'pointer',
        marginBottom: '1rem',
    },
    text: {
        fontSize: '0.9rem',
        color: '#555',
        marginBottom: '1rem',
    },
    registerLink: {
        display: 'inline-block',
        width: '100%',
        padding: '.75rem',
        backgroundColor: '#f8f9fa',
        color: '#007bff',
        borderRadius: '4px',
        textDecoration: 'none',
        textAlign: 'center',
    },
};

export default Register;
