import React from 'react';
import Profile from '../components/profile/Profile';

const App = () => {
  const userId = 1; // Replace with dynamic user ID as needed

  return (
    <div>
      <Profile />
    </div>
  );
};

export default App;
