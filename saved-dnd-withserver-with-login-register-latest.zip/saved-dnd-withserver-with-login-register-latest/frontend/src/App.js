import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import BoardContainer from './pages/BoardContainer';
import NotionMainPage from './pages/NotionMainPage';
import Personal from './pages/Personal';
import Calendar from './pages/Calender';
import Profile from './pages/Profile';
import Login from './pages/Login';
import Register from './pages/Register';
import PrivateRoute from './components/login/PrivateRoute';
import { AuthProvider } from './components/login/AuthContext';
import ToDoList from './components/to_do_list/ToDoList';
import GanttChart from './pages/GanttChart';

import './App.css';

function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="App">
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route
              path="/personal"
              element={
                <PrivateRoute>
                  <Personal />
                </PrivateRoute>
              }
            />
            <Route
              path="/workspace"
              element={
                <PrivateRoute>
                  <BoardContainer />
                </PrivateRoute>
              }
            />
            <Route
              path="/"
              element={
                <PrivateRoute>
                  <NotionMainPage />
                </PrivateRoute>
              }
            />
            <Route
              path="/calendar"
              element={
                <PrivateRoute>
                  <Calendar />
                </PrivateRoute>
              }
            />
            <Route
              path="/to-do-list"
              element={
                <PrivateRoute>
                  <ToDoList />
                </PrivateRoute>
              }
            />
            <Route
              path="/gantchart"
              element={
                <PrivateRoute>
                  <GanttChart />
                </PrivateRoute>
              }
            />
            <Route
              path="/profile"
              element={
                <PrivateRoute>
                  <Profile />
                </PrivateRoute>
              }
            />
          </Routes>
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;
