// src/components/login/AuthContext.js
import React, { createContext, useState, useEffect } from 'react';
import axios from 'axios';

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(true);
  const [userEmail, setUserEmail] = useState(localStorage.getItem('userEmail') || '');

  useEffect(() => {
    axios.get('http://localhost:5000/auth', { withCredentials: true })
      .then(response => {
        if (response.data.Status === "Success") {
          setIsAuthenticated(true);
        }
        setLoading(false);
      })
      .catch(error => {
        console.error('Authentication check failed', error);
        setLoading(false);
      });
  }, []);

  useEffect(() => {
    localStorage.setItem('userEmail', userEmail);
  }, [userEmail]);

  if (loading) {
    return <div>Loading...</div>; // You can replace this with a loading spinner if desired
  }

  return (
    <AuthContext.Provider value={{ isAuthenticated, setIsAuthenticated, userEmail, setUserEmail }}>
      {children}
    </AuthContext.Provider>
  );
};
