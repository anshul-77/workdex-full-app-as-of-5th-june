import React, { useState } from 'react';

const AddCardForm = ({ addCard }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    addCard(title, content);
    setTitle('');
    setContent('');
    setIsModalOpen(false);
  };

  return (
    <>
      <button onClick={() => setIsModalOpen(true)} style={styles.addCardButton}>
        + Add Card
      </button>
      {isModalOpen && (
        <div style={styles.modalOverlay}>
          <div style={styles.modalContent}>
            <h2 style={styles.heading}>Add New Card</h2>
            <form onSubmit={handleSubmit} style={styles.form}>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Card Title"
                style={styles.input}
              />
              <textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Card Content"
                style={styles.textarea}
              />
              <div style={styles.buttonGroup}>
                <button type="submit" style={styles.submitButton}>Add Card</button>
                <button type="button" onClick={() => setIsModalOpen(false)} style={styles.cancelButton}>Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
};

const styles = {
  addCardButton: {
    background: 'none',
    border: 'none',
    color: '#007bff',
    cursor: 'pointer',
    fontSize: '16px',
    padding: '10px',
    marginBottom: '10px',
  },
  modalOverlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
  },
  modalContent: {
    backgroundColor: '#fff',
    padding: '20px',
    borderRadius: '8px',
    width: '300px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'stretch',
  },
  heading: {
    margin: '0 0 20px 0',
    fontSize: '1.5em',
    color: '#333',
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'stretch',
  },
  input: {
    padding: '8px',
    marginBottom: '10px',
    borderRadius: '4px',
    border: '1px solid #ddd',
    fontSize: '1em',
    width: '100%',
  },
  textarea: {
    padding: '8px',
    marginBottom: '20px',
    borderRadius: '4px',
    border: '1px solid #ddd',
    fontSize: '1em',
    minHeight: '80px',
    width: '100%',
    resize: 'vertical',
  },
  buttonGroup: {
    display: 'flex',
    justifyContent: 'space-between',
  },
  submitButton: {
    padding: '10px',
    borderRadius: '4px',
    border: 'none',
    fontSize: '1em',
    cursor: 'pointer',
    backgroundColor: '#28a745',
    color: '#fff',
    flex: '1',
    margin: '0 5px',
  },
  cancelButton: {
    padding: '10px',
    borderRadius: '4px',
    border: 'none',
    fontSize: '1em',
    cursor: 'pointer',
    backgroundColor: '#dc3545',
    color: '#fff',
    flex: '1',
    margin: '0 5px',
  }
};

export default AddCardForm;

