import React from 'react';

const ConfirmDeleteModal = ({ listName, onConfirm, onCancel }) => {
  return (
    <div style={styles.overlay}>
      <div style={styles.modal}>
        <h2>Delete List</h2>
        <p>Are you sure you want to delete the list "{listName}"?</p>
        <div style={styles.buttons}>
          <button onClick={onCancel} style={styles.cancelButton}>Cancel</button>
          <button onClick={onConfirm} style={styles.confirmButton}>Delete</button>
        </div>
      </div>
    </div>
  );
};

const styles = {
  overlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1000,
  },
  modal: {
    backgroundColor: '#fff',
    padding: '20px',
    borderRadius: '8px',
    boxShadow: '0 2px 10px rgba(0, 0, 0, 0.1)',
    textAlign: 'center',
  },
  buttons: {
    marginTop: '20px',
    display: 'flex',
    justifyContent: 'space-between',
  },
  cancelButton: {
    backgroundColor: '#ccc',
    border: 'none',
    padding: '10px 20px',
    borderRadius: '4px',
    cursor: 'pointer',
  },
  confirmButton: {
    backgroundColor: '#d9534f',
    border: 'none',
    padding: '10px 20px',
    borderRadius: '4px',
    color: '#fff',
    cursor: 'pointer',
  },
};

export default ConfirmDeleteModal;
