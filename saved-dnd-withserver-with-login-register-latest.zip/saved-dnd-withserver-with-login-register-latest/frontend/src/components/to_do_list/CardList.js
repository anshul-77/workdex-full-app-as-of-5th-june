import React, { useState } from 'react';
import { Droppable, Draggable } from 'react-beautiful-dnd';
import Card from './Card';
import AddCardForm from './AddCardForm';
import ConfirmDeleteModal from './ConfirmDeleteModal';

const CardList = ({ listId, listName, cards, onCardClick, addCard, deleteList, style }) => {
  const [showConfirmDelete, setShowConfirmDelete] = useState(false);

  const handleDeleteList = () => {
    setShowConfirmDelete(true);
  };

  const confirmDeleteList = () => {
    deleteList(listId);
    setShowConfirmDelete(false);
  };

  return (
    <Droppable droppableId={listId.toString()}>
      {(provided) => (
        <div
          ref={provided.innerRef}
          {...provided.droppableProps}
          style={{ ...styles.cardList, ...style }}
        >
          <div style={styles.header}>
            <h3 style={styles.listName}>{listName}</h3>
            <button onClick={handleDeleteList} style={styles.deleteButton}>X</button>
          </div>
          {cards.map((card, index) => (
            <Draggable key={card.id.toString()} draggableId={card.id.toString()} index={index}>
              {(provided, snapshot) => (
                <div
                  ref={provided.innerRef}
                  {...provided.draggableProps}
                  {...provided.dragHandleProps}
                  style={{
                    ...styles.draggable,
                    ...provided.draggableProps.style,
                    boxShadow: snapshot.isDragging ? '0 4px 8px rgba(0, 0, 0, 0.2)' : 'none',
                  }}
                >
                  <Card card={card} onClick={() => onCardClick(card)} />
                </div>
              )}
            </Draggable>
          ))}
          {provided.placeholder}
          <AddCardForm addCard={(title, content) => addCard(listId, title, content)} />
          {showConfirmDelete && (
            <ConfirmDeleteModal
              listName={listName}
              onConfirm={confirmDeleteList}
              onCancel={() => setShowConfirmDelete(false)}
            />
          )}
        </div>
      )}
    </Droppable>
  );
};

const styles = {
  cardList: {
    padding: '10px', // Reduced padding
    backgroundColor: '#f7f7f7',
    borderRadius: '12px',
    minHeight: '200px', // Reduced height
    margin: '0 5px', // Reduced margin
    width: '240px', // Reduced width
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    transition: 'transform 0.2s',
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: '100%',
    marginBottom: '5px', // Reduced margin-bottom
  },
  listName: {
    margin: 0,
    fontSize: '1.1em', // Slightly smaller font-size
  },
  deleteButton: {
    backgroundColor: 'transparent',
    border: 'none',
    color: '#d9534f',
    fontSize: '1.1em', // Slightly smaller font-size
    cursor: 'pointer',
  },
  draggable: {
    marginBottom: '8px', // Reduced margin-bottom
    width: '100%',
    height: '80px', // Reduced height
    backgroundColor: '#fff',
    borderRadius: '8px',
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    transition: 'transform 0.2s',
  },
};

export default CardList;
