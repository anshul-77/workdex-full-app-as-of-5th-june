import React, { useState } from 'react';

const CardModal = ({ card, onSave, onDelete, onClose }) => {
const [title, setTitle] = useState(card.title);
const [content, setContent] = useState(card.content);

const handleSave = () => {
onSave(card.id, title, content);
};

return (

<div style={styles.modalOverlay}>
<div style={styles.modalContent}>
<h2 style={styles.heading}>Edit Card</h2>
<input
type="text"
value={title}
onChange={(e) => setTitle(e.target.value)}
style={styles.input}
/>
<textarea
value={content}
onChange={(e) => setContent(e.target.value)}
style={styles.textarea}
/>
<div style={styles.buttonGroup}>
<button onClick={handleSave} style={{ ...styles.button, ...styles.saveButton }}>Save</button>
<button onClick={() => onDelete(card.id)} style={{ ...styles.button, ...styles.deleteButton }}>Delete</button>
<button onClick={onClose} style={{ ...styles.button, ...styles.closeButton }}>Close</button>
</div>
</div>
</div>
);
};
const styles = {
modalOverlay: {
position: 'fixed',
top: 0,
left: 0,
right: 0,
bottom: 0,
backgroundColor: 'rgba(0, 0, 0, 0.5)',
display: 'flex',
justifyContent: 'center',
alignItems: 'center',
zIndex: 1000, // Ensure it's on top
},
modalContent: {
backgroundColor: '#fff',
padding: '20px',
borderRadius: '8px',
width: '300px',
boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
display: 'flex',
flexDirection: 'column',
alignItems: 'stretch',
},
heading: {
margin: '0 0 20px 0',
fontSize: '1.5em',
color: '#333',
},
input: {
padding: '8px',
marginBottom: '10px',
borderRadius: '4px',
border: '1px solid #ddd',
fontSize: '1em',
width: '100%',
},
textarea: {
padding: '8px',
marginBottom: '20px',
borderRadius: '4px',
border: '1px solid #ddd',
fontSize: '1em',
minHeight: '80px',
width: '100%',
resize: 'vertical', // Allow vertical resizing
},
buttonGroup: {
display: 'flex',
justifyContent: 'space-between',
},
button: {
padding: '10px',
borderRadius: '4px',
border: 'none',
fontSize: '1em',
cursor: 'pointer',
transition: 'background-color 0.3s',
flex: '1',
margin: '0 5px',
},
saveButton: {
backgroundColor: '#28a745',
color: '#fff',
},
deleteButton: {
backgroundColor: '#dc3545',
color: '#fff',
},
closeButton: {
backgroundColor: '#6c757d',
color: '#fff',
}
};

export default CardModal;