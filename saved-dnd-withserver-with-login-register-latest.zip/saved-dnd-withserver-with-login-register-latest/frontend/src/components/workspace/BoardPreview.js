import React from 'react';

const BoardPreview = ({ boardId, boardName, onClick }) => {
  return (
    <div onClick={() => onClick(boardId)} style={styles.boardPreview}>
      <p style={styles.boardName}>{boardName}</p>
    </div>
  );
};

const styles = {
  boardPreview: {
    padding: '20px',
    backgroundColor: '#f7f7f7',
    borderRadius: '12px',
    minHeight: '100px',
    margin: '10px',
    width: '200px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    cursor: 'pointer',
    transition: 'transform 0.2s',
    textAlign: 'center',
  },
  boardName: {
    margin: 0,
    fontSize: '1.2em',
  },
};

export default BoardPreview;
