import React, { useState } from 'react';
import axios from 'axios';

const TopBar = () => {
  const [showDropdown, setShowDropdown] = useState(false);

  const handleDelete = () => {
    axios.get('http://localhost:5000/logout', { withCredentials: true })
      .then(res => {
        if (res.data.Status === "Success") {
          window.location.href = "/login"; // Redirect to home or login page
        } else {
          console.log("Logout failed: ", res.data.Error);
        }
      })
      .catch(err => console.log(err));
  };
  
  const topBarStyle = {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '10px 20px',
    backgroundColor: '#b3e6ff',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
    position: 'relative',
    fontFamily: "'Comic Sans MS', cursive, sans-serif",
    borderRadius: '15px',
    width: '90%',
    margin: '10px auto',
  };

  const searchBarStyle = {
    width: '180px',
    padding: '5px',
    borderRadius: '20px',
    border: '1px solid #0088cc',
    backgroundColor: '#e6f7ff',
    fontFamily: "'Comic Sans MS', cursive, sans-serif",
  };

  const topBarButtonsContainerStyle = {
    display: 'flex',
    alignItems: 'center',
  };

  const topBarButtonStyle = {
    marginLeft: '10px',
    padding: '5px 10px',
    backgroundColor: '#e6f7ff',
    border: '1px solid #0088cc',
    borderRadius: '12px',
    cursor: 'pointer',
    transition: 'background-color 0.3s, transform 0.2s',
    color: '#000000',
    fontFamily: "'Comic Sans MS', cursive, sans-serif",
  };

  const topBarButtonHoverStyle = {
    backgroundColor: '#0088cc',
    transform: 'scale(1.05)',
    color: '#ffffff',
  };

  const profileContainerStyle = {
    position: 'relative',
    display: 'inline-block',
    marginLeft: '10px',
  };

  const profilePictureStyle = {
    width: '40px',
    height: '40px',
    borderRadius: '50%',
    cursor: 'pointer',
    border: '2px solid #0088cc',
  };

  const dropdownMenuStyle = {
    display: showDropdown ? 'block' : 'none',
    position: 'absolute',
    top: '50px',
    right: '0',
    backgroundColor: '#e6f7ff',
    border: '1px solid #0088cc',
    borderRadius: '12px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    zIndex: 1,
    minWidth: '150px',
  };

  const dropdownMenuItemStyle = {
    padding: '10px',
    cursor: 'pointer',
    transition: 'background-color 0.3s',
    color: '#000000',
    textAlign: 'center',
    fontFamily: "'Comic Sans MS', cursive, sans-serif",
  };

  const dropdownMenuItemHoverStyle = {
    backgroundColor: '#0088cc',
    color: '#ffffff',
  };

  const handleProfileClick = () => {
    setShowDropdown(!showDropdown);
  };

  const handleMouseEnter = (event, style) => {
    Object.assign(event.target.style, style);
  };

  const handleMouseLeave = (event, style) => {
    Object.assign(event.target.style, style);
  };

  const navigateTo = (path) => {
    window.location.href = path;
  };

  return (
    <div style={topBarStyle}>
      <input type="text" placeholder="Search..." style={searchBarStyle} />
      <div style={topBarButtonsContainerStyle}>
        <button
          style={topBarButtonStyle}
          onMouseEnter={(e) => handleMouseEnter(e, topBarButtonHoverStyle)}
          onMouseLeave={(e) => handleMouseLeave(e, topBarButtonStyle)}
          onClick={() => navigateTo('/new-page')}
        >
          New Page
        </button>
        <button
          style={topBarButtonStyle}
          onMouseEnter={(e) => handleMouseEnter(e, topBarButtonHoverStyle)}
          onMouseLeave={(e) => handleMouseLeave(e, topBarButtonStyle)}
          onClick={() => navigateTo('/help')}
        >
          Help
        </button>
        <button
          style={topBarButtonStyle}
          onMouseEnter={(e) => handleMouseEnter(e, topBarButtonHoverStyle)}
          onMouseLeave={(e) => handleMouseLeave(e, topBarButtonStyle)}
          onClick={() => navigateTo('/calendar')}
        >
          <img
            src="https://w7.pngwing.com/pngs/162/843/png-transparent-computer-icons-calendar-date-others-miscellaneous-text-calendar.png"
            alt="Calendar"
            style={{ width: '20px', height: '20px' }}
          />
        </button>
        <div style={profileContainerStyle}>
          <img
            src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png"
            alt="Profile"
            style={profilePictureStyle}
            onClick={handleProfileClick}
          />
          <div style={dropdownMenuStyle}>
            {['Profile', 'Settings', 'Logout'].map((item) => (
              <div
                key={item}
                style={dropdownMenuItemStyle}
                onMouseEnter={(e) => handleMouseEnter(e, dropdownMenuItemHoverStyle)}
                onMouseLeave={(e) => handleMouseLeave(e, dropdownMenuItemStyle)}
                onClick={item === 'Logout' ? handleDelete : () => navigateTo(`/${item.toLowerCase()}`)}
              >
                {item}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TopBar;
