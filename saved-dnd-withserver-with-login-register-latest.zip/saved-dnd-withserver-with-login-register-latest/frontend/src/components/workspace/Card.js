import React, { useState } from 'react';

const Card = ({ card, onClick }) => {
  const getFirstWords = (content, wordCount = 4) => {
    const div = document.createElement("div");
    div.innerHTML = content;
    const textContent = div.textContent || div.innerText || "";
    const words = textContent.split(' ');
    return words.slice(0, wordCount).join(' ');
  };

  const firstWords = getFirstWords(card.content);

  return (
    <div className="card" onClick={() => onClick(card)} style={{ ...styles.card, borderColor: card.labels }}>
      <h2 style={styles.title}>{card.title}</h2>
      <div style={styles.content} dangerouslySetInnerHTML={{ __html: `${firstWords}...` }} />
    </div>
  );
};

const styles = {
  card: {
    backgroundColor: '#99ffbb',
    borderRadius: '8px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    padding: '16px',
    margin: '8px 0',
    width: '100%',
    cursor: 'pointer',
    transition: 'transform 0.2s',
    border: '2px solid', // Adjust the border style to show label color
  },
  title: {
    fontSize: '1.2em',
    margin: '0 0 8px 0',
    color: '#333',
    fontWeight: 'bold',
  },
  content: {
    fontSize: '1em',
    color: '#666',
  },
};

export default Card;
