import React, { useState, useEffect } from 'react';
import ReactQuill from 'react-quill';
import axios from 'axios';
import 'react-quill/dist/quill.snow.css';

const CardModal = ({ card, onSave, onDelete, onClose }) => {
  const [title, setTitle] = useState(card.title);
  const [content, setContent] = useState(card.content);
  const [labels, setLabels] = useState(card.labels || '');
  const [checklists, setChecklists] = useState([]);
  const [newChecklistContent, setNewChecklistContent] = useState('');
  const [showChecklists, setShowChecklists] = useState(false);

  useEffect(() => {
    const fetchChecklists = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/cards/${card.id}/checklists`);
        setChecklists(response.data);
      } catch (error) {
        console.error('Error fetching checklists', error);
      }
    };

    fetchChecklists();
  }, [card.id]);

  const handleSave = () => {
    onSave(card.id, title, content, card.list_id, labels);
  };

  const addChecklistItem = async () => {
    if (!newChecklistContent.trim()) return;
    try {
      const response = await axios.post('http://localhost:5000/checklists', {
        card_id: card.id,
        content: newChecklistContent,
      });
      setChecklists([...checklists, response.data]);
      setNewChecklistContent('');
    } catch (error) {
      console.error('Error adding checklist item', error);
    }
  };

  const updateChecklistItem = async (id, updatedContent, isCompleted) => {
    try {
      const response = await axios.put(`http://localhost:5000/checklists/${id}`, {
        content: updatedContent,
        is_completed: isCompleted,
      });
      setChecklists(checklists.map(item => (item.id === id ? response.data : item)));
    } catch (error) {
      console.error('Error updating checklist item', error);
    }
  };

  const deleteChecklistItem = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/checklists/${id}`);
      setChecklists(checklists.filter(item => item.id !== id));
    } catch (error) {
      console.error('Error deleting checklist item', error);
    }
  };

  const getCompletionPercentage = () => {
    if (checklists.length === 0) return 0;
    const completedTasks = checklists.filter(item => item.is_completed).length;
    return Math.round((completedTasks / checklists.length) * 100);
  };

  return (
    <div style={styles.modalOverlay}>
      <div style={styles.modalContent}>
        <button onClick={onClose} style={styles.closeButton}>×</button>
        <div style={styles.mainContent}>
          <h2 style={styles.heading}>Edit Card</h2>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            style={styles.input}
          />
          <ReactQuill
            value={content}
            onChange={setContent}
            style={styles.quillEditor}
            theme="snow"
          />
          <div style={styles.buttonGroup}>
            <div style={styles.saveDeleteButtons}>
              <button onClick={handleSave} style={{ ...styles.button, ...styles.saveButton }}>Save</button>
              <button onClick={() => onDelete(card.id)} style={{ ...styles.button, ...styles.deleteButton }}>Delete</button>
            </div>
          </div>
        </div>
        <div style={styles.sideSection}>
          <h3 style={styles.sideHeading}>Add Label</h3>
          <div style={styles.labelSelector}>
            <button
              style={{ ...styles.labelButton, backgroundColor: 'red' }}
              onClick={() => setLabels('red')}
            />
            <button
              style={{ ...styles.labelButton, backgroundColor: 'green' }}
              onClick={() => setLabels('green')}
            />
            <button
              style={{ ...styles.labelButton, backgroundColor: 'blue' }}
              onClick={() => setLabels('blue')}
            />
            <button
              style={{ ...styles.labelButton, backgroundColor: 'gray' }}
              onClick={() => setLabels('')}
            >🚫</button>
          </div>
          <button onClick={() => setShowChecklists(!showChecklists)} style={styles.toggleChecklistButton}>
            {showChecklists ? '− Checklist' : '+ Checklist'}
          </button>

          {showChecklists && (
            <div style={styles.checklist}>
              <div style={styles.completionPercentage}>
                {getCompletionPercentage()}% tasks completed
                <div style={styles.progressBarContainer}>
                  <div style={{ ...styles.progressBar, width: `${getCompletionPercentage()}%` }}></div>
                </div>
              </div>
              {checklists.map(item => (
                <div key={item.id} style={styles.checklistItem}>
                  <input
                    type="checkbox"
                    checked={item.is_completed}
                    onChange={() => updateChecklistItem(item.id, item.content, !item.is_completed)}
                    style={styles.checkbox}
                  />
                  <input
                    type="text"
                    value={item.content}
                    onChange={(e) => updateChecklistItem(item.id, e.target.value, item.is_completed)}
                    style={styles.checklistInput}
                  />
                  <button onClick={() => deleteChecklistItem(item.id)} style={styles.deleteChecklistButton}>×</button>
                </div>
              ))}
              <div style={styles.newChecklistItem}>
                <input
                  type="text"
                  value={newChecklistContent}
                  onChange={(e) => setNewChecklistContent(e.target.value)}
                  placeholder="Add new checklist item"
                  style={styles.checklistInput}
                />
                <button onClick={addChecklistItem} style={styles.addChecklistButton}>+</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const styles = {
  modalOverlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
  },
  modalContent: {
    position: 'relative',
    backgroundColor: '#fff',
    padding: '20px',
    borderRadius: '8px',
    width: '800px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'stretch',
  },
  mainContent: {
    flex: '1',
    marginRight: '20px',
  },
  sideSection: {
    width: '250px',
    backgroundColor: '#f0f0f0',
    padding: '20px',
    borderRadius: '8px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
  },
  sideHeading: {
    fontSize: '1.25em',
    marginBottom: '15px',
    color: '#333',
    textAlign: 'center',
  },
  heading: {
    fontSize: '1.5em',
    marginBottom: '15px',
    color: '#333',
  },
  input: {
    width: '100%',
    padding: '10px',
    fontSize: '1em',
    borderRadius: '5px',
    border: '1px solid #ddd',
    marginBottom: '15px',
  },
  buttonGroup: {
    display: 'flex',
    justifyContent: 'space-between',
    marginTop: '20px',
  },
  saveDeleteButtons: {
    display: 'flex',
    gap: '10px',
  },
  button: {
    padding: '5px 10px',
    fontSize: '1em',
    borderRadius: '5px',
    cursor: 'pointer',
    border: 'none',
  },
  saveButton: {
    marginTop: '30px',
    backgroundColor: 'green',
    color: '#fff',
  },
  deleteButton: {
    marginTop: '30px',
    backgroundColor: 'red',
    color: '#fff',
  },
  closeButton: {
    position: 'absolute',
    top: '1px',
    right: '1px',
    backgroundColor: 'transparent',
    border: 'none',
    color: '#333',
    cursor: 'pointer',
    fontSize: '1.5em',
  },
  labelSelector: {
    display: 'flex',
    justifyContent: 'space-between',
    marginBottom: '15px',
  },
  labelButton: {
    width: '40px',
    height: '25px',
    borderRadius: '20%',
    border: 'none',
    cursor: 'pointer',
  },
  toggleChecklistButton: {
    background: 'transparent',
    border: 'none',
    color: '#007bff',
    cursor: 'pointer',
    padding: '0',
    fontSize: '1em',
  },
  checklist: {
    marginTop: '15px',
    padding: '10px',
    backgroundColor: '#f9f9f9',
    borderRadius: '5px',
    boxShadow: '0 1px 3px rgba(0, 0, 0, 0.1)',
  },
  completionPercentage: {
    textAlign: 'center',
    fontWeight: 'bold',
    marginBottom: '10px',
  },
  progressBarContainer: {
    height: '10px',
    backgroundColor: '#ddd',
    borderRadius: '5px',
    overflow: 'hidden',
    marginTop: '5px',
  },
  progressBar: {
    height: '100%',
    backgroundColor: 'green',
    transition: 'width 0.3s ease',
  },
  checklistItem: {
    display: 'flex',
    alignItems: 'center',
    marginBottom: '10px',
    backgroundColor: '#fff',
    padding: '2px',
    borderRadius: '5px',
    boxShadow: '0 1px 3px rgba(0, 0, 0, 0.1)',
  },
  checkbox: {
    width: '18px', // Larger checkbox
    height: '18px', // Larger checkbox
    marginRight: '10px', // Gap between checkbox and text
  },
  checklistInput: {
    flex: '1',
    padding: '2px',
    borderRadius: '3px',
    border: '1px solid #ddd',
    marginRight: '10px',
    fontSize: '0.69em', // Smaller font size
  },
  deleteChecklistButton: {
    backgroundColor: 'transparent',
    color: 'red',
    border: 'none',
    cursor: 'pointer',
    padding: '0',
    display: 'flex',
    alignItems: 'center', // Align vertically
  },
  newChecklistItem: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#fff',
    padding: '5px',
    borderRadius: '5px',
    boxShadow: '0 1px 3px rgba(0, 0, 0, 0.1)',
  },
  addChecklistButton: {
    backgroundColor: 'transparent',
    color: 'green',
    border: 'none',
    cursor: 'pointer',
    borderRadius: '3px',
    padding: '3px 5px', // Smaller padding
    fontSize: '0.9em', // Smaller font size
    display: 'flex',
    alignItems: 'center', // Align vertically
  },
  quillEditor: {
    height: '200px',
    marginBottom: '15px',
  },
  transparentButton: {
    background: 'transparent',
    border: 'none',
    color: '#007bff',
    cursor: 'pointer',
    textDecoration: 'underline',
    padding: '0',
    fontSize: '1em',
  },
};

export default CardModal;
