import React from 'react';

const Sidebar = () => {
  const sidebarStyle = {
    width: '250px',
    backgroundColor: '#b3e6ff', // Lighter, more playful color
    padding: '20px',
    borderRadius: '10px', // Rounded corners 
    fontFamily: "'Comic Sans MS', cursive, sans-serif", // Playful font
    overflowY: 'auto', // Allow scrolling if content overflows
  };

  const sidebarHeaderStyle = {
    fontSize: '1.8em',
    marginBottom: '20px',
    color: '#0088cc', // Teal color for the header text
    textAlign: 'center', // Center align the header
  };

  const sidebarMenuStyle = {
    listStyle: 'none',
    padding: '0',
  };

  const sidebarMenuItemStyle = {
    padding: '10px 0',
    cursor: 'pointer',
    borderRadius: '5px',
    transition: 'background-color 0.3s, transform 0.2s', // Smooth transitions
    textAlign: 'center', // Center align the menu items
    textDecoration: 'none',
    color: 'inherit',
  };

  const sidebarMenuItemDefaultStyle = {
    backgroundColor: 'inherit',
    color: 'inherit',
    transform: 'scale(1)',
  };

  const sidebarMenuItemHoverStyle = {
    backgroundColor: '#0088cc', // Gold background on hover
    color: '#FFFFFF', // White text on hover
    transform: 'scale(1.05)', // Slightly enlarge on hover
  };

  // Function to apply hover styles
  const applyHoverStyles = (event, isHovering) => {
    const style = isHovering ? sidebarMenuItemHoverStyle : sidebarMenuItemDefaultStyle;
    Object.assign(event.target.style, style);
  };

  // Function to handle navigation
  const navigateTo = (path) => {
    // Perform navigation here, for example:
    window.location.href = path;
  };

  return (
    <div style={sidebarStyle}>
      <div style={sidebarHeaderStyle}><h3>WorkDex</h3></div>
      <ul style={sidebarMenuStyle}>
        <li
          style={sidebarMenuItemStyle}
          onMouseEnter={(e) => applyHoverStyles(e, true)}
          onMouseLeave={(e) => applyHoverStyles(e, false)}
          onClick={() => navigateTo('/')}
        >
          Home
        </li>
        <li
          style={sidebarMenuItemStyle}
          onMouseEnter={(e) => applyHoverStyles(e, true)}
          onMouseLeave={(e) => applyHoverStyles(e, false)}
          onClick={() => navigateTo('/personal')}
        >
          Personal
        </li>
      </ul>
    </div>
  );
};

export default Sidebar;
