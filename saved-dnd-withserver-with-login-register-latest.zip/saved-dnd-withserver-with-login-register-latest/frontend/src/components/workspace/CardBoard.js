import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import { DragDropContext } from 'react-beautiful-dnd';
import CardList from './CardList';
import CardModal from './CardModal';
import AddListForm from './AddListForm';

const CardBoard = ({ boardId, onClose }) => {
  const [lists, setLists] = useState({});
  const [selectedCard, setSelectedCard] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchLists = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const listResponse = await axios.get(`http://localhost:5000/boards/${boardId}/lists`);
      const listsData = listResponse.data;

      const newLists = {};
      const cardPromises = listsData.map(async (list) => {
        const cardResponse = await axios.get(`http://localhost:5000/lists/${list.id}/cards`);
        newLists[list.id] = { name: list.name, cards: cardResponse.data };
      });

      await Promise.all(cardPromises);
      setLists(newLists);
    } catch (error) {
      setError('Error fetching lists and cards');
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  }, [boardId]);

  useEffect(() => {
    fetchLists();
  }, [fetchLists]);

  const addCard = async (listId, title, content) => {
    try {
      const response = await axios.post('http://localhost:5000/cards', { list_id: listId, title, content });
      const newCard = response.data;

      setLists((prevLists) => ({
        ...prevLists,
        [listId]: { ...prevLists[listId], cards: [...prevLists[listId].cards, newCard] }
      }));
    } catch (error) {
      setError('Error adding card');
      console.error(error);
    }
  };

  const addList = async (listName) => {
    try {
      const response = await axios.post('http://localhost:5000/lists', { name: listName, board_id: boardId });
      const newList = response.data;

      setLists((prevLists) => ({
        ...prevLists,
        [newList.id]: { name: newList.name, cards: [] }
      }));
    } catch (error) {
      setError('Error adding list');
      console.error(error);
    }
  };

  const deleteList = async (listId) => {
    console.log(`Deleting list with id: ${listId}`);
    try {
      await axios.delete(`http://localhost:5000/lists/${listId}`);
      setLists((prevLists) => {
        const newLists = { ...prevLists };
        delete newLists[listId];
        return newLists;
      });
    } catch (error) {
      setError('Error deleting list');
      console.error(error);
    }
  };

  const onDragEnd = async (result) => {
    if (!result.destination) return;

    const { source, destination } = result;

    if (source.droppableId === destination.droppableId && source.index === destination.index) {
      return;
    }

    const startList = lists[source.droppableId];
    const endList = lists[destination.droppableId];

    if (startList === endList) {
      // Move card within the same list
      const newCards = Array.from(startList.cards);
      const [movedCard] = newCards.splice(source.index, 1);
      newCards.splice(destination.index, 0, movedCard);

      const newList = {
        ...startList,
        cards: newCards,
      };

      setLists((prevLists) => ({
        ...prevLists,
        [source.droppableId]: newList,
      }));
    } else {
      // Move card to a different list
      const startCards = Array.from(startList.cards);
      const endCards = Array.from(endList.cards);
      const [movedCard] = startCards.splice(source.index, 1);
      endCards.splice(destination.index, 0, movedCard);

      const newStartList = {
        ...startList,
        cards: startCards,
      };
      const newEndList = {
        ...endList,
        cards: endCards,
      };

      setLists((prevLists) => ({
        ...prevLists,
        [source.droppableId]: newStartList,
        [destination.droppableId]: newEndList,
      }));

      try {
        await axios.put(`http://localhost:5000/cards/${movedCard.id}`, { list_id: destination.droppableId });
      } catch (error) {
        setError('Error updating card list');
        console.error(error);
      }
    }
  };

  const handleCardClick = (card) => {
    setSelectedCard(card);
  };

  const handleSaveCard = async (id, newTitle, newContent,listId,newLabels) => {
    try {
      await axios.put(`http://localhost:5000/cards/${id}/update`, { title: newTitle, content: newContent,list_id: listId, labels: newLabels });

      setLists((prevLists) => {
        const updatedLists = { ...prevLists };
        for (const listId in updatedLists) {
          updatedLists[listId].cards = updatedLists[listId].cards.map(card =>
            card.id === id ? { ...card, title: newTitle, content: newContent, labels: newLabels } : card
          );
        }
        return updatedLists;
      });
      setSelectedCard(null);
    } catch (error) {
      setError('Error updating card');
      console.error(error);
    }
  };

  const handleDeleteCard = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/cards/${id}`);

      setLists((prevLists) => {
        const updatedLists = { ...prevLists };
        for (const listId in updatedLists) {
          updatedLists[listId].cards = updatedLists[listId].cards.filter(card => card.id !== id);
        }
        return updatedLists;
      });
      setSelectedCard(null);
    } catch (error) {
      setError('Error deleting card');
      console.error(error);
    }
  };

  if (isLoading) {
    return <div style={styles.loading}>Loading...</div>;
  }

  if (error) {
    return <div style={styles.error}>{error}</div>;
  }

  return (
    <div style={styles.overlay}>
      <div style={styles.container}>
        <button onClick={onClose} style={styles.closeButton}>×</button>
        <AddListForm addList={addList} />
        <DragDropContext onDragEnd={onDragEnd}>
          <div style={styles.listsContainer}>
            {Object.keys(lists).map((listId, index) => (
              <CardList
                key={listId}
                listId={listId}
                listName={lists[listId].name}
                cards={lists[listId].cards}
                onCardClick={handleCardClick}
                addCard={addCard}
                deleteList={deleteList}
                style={index > 0 ? { marginLeft: '10px' } : null} // Adjusted margin for smaller lists
              />
            ))}
          </div>
        </DragDropContext>
        {selectedCard && (
          <CardModal
            card={selectedCard}
            onSave={handleSaveCard}
            onDelete={handleDeleteCard}
            onClose={() => setSelectedCard(null)}
          />
        )}
      </div>
    </div>
  );
};

const styles = {
  overlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
  },
  
  container: {
    position: 'relative',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    padding: '20px',
    backgroundColor: '#99ccff',
    height: '90vh',
    width: '95%',
    maxWidth: '1500px',
    boxSizing: 'border-box',
    margin: '20px auto',
    borderRadius: '20px',
    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
  },
  
  listsContainer: {
    display: 'flex',
    flexWrap: 'wrap',
    gap: '10px',
    width: '100%',
    justifyContent: 'center',
    padding: '20px 0',
  },
  loading: {
    fontSize: '1.5em',
    color: '#333',
    marginTop: '20px',
  },
  error: {
    fontSize: '1.2em',
    color: 'red',
    marginTop: '20px',
  },
  closeButton: {
    position: 'absolute',
    top: '10px',
    right: '10px',
    backgroundColor: 'transparent',
    border: 'none',
    fontSize: '1.5em',
    cursor: 'pointer',
    color: '#333',
  },
};

export default CardBoard;
