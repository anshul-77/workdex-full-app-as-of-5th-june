import React, { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../login/AuthContext';
import ConfirmDeleteDialog from './ConfirmDeleteDialog';

const MainContent = ({ searchQuery }) => {
  const [cards, setCards] = useState([]);
  const [newCardTitle, setNewCardTitle] = useState('');
  const [newCardContent, setNewCardContent] = useState('');
  const [newCardLabel, setNewCardLabel] = useState('none');
  const [zoomedCard, setZoomedCard] = useState(null);
  const [cardToDelete, setCardToDelete] = useState(null);
  const { userEmail } = useContext(AuthContext);

  const [currentPage, setCurrentPage] = useState(0);
  const cardsPerPage = 6;

  const [labelFilter, setLabelFilter] = useState('all');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/stamps?email=${userEmail}`);
        setCards(response.data);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };
    fetchData();
  }, [userEmail]);

  const handleSave = async (cardId, field, value) => {
    const cardToSave = cards.find((card) => card.id === cardId);
    const updatedCard = { ...cardToSave, [field]: value };

    try {
      await axios.put(`http://localhost:5000/stamps/${cardId}`, updatedCard);
      const updatedCards = cards.map((card) =>
        card.id === cardId ? updatedCard : card
      );
      setCards(updatedCards);
    } catch (error) {
      console.error('Error saving data:', error);
    }
  };

  const handleDelete = async () => {
    if (cardToDelete) {
      try {
        await axios.delete(`http://localhost:5000/stamps/${cardToDelete}`);
        const updatedCards = cards.filter((card) => card.id !== cardToDelete);
        setCards(updatedCards);
        setCardToDelete(null);
      } catch (error) {
        console.error('Error deleting card:', error);
      }
    }
  };

  const confirmDelete = (cardId) => {
    setCardToDelete(cardId);
  };

  const handleCancelDelete = () => {
    setCardToDelete(null);
  };

  const handleTitleChange = (event, cardId) => {
    const updatedCards = cards.map((card) =>
      card.id === cardId ? { ...card, title: event.target.value } : card
    );
    setCards(updatedCards);
  };

  const handleContentChange = (event, cardId) => {
    const updatedCards = cards.map((card) =>
      card.id === cardId ? { ...card, content: event.target.value } : card
    );
    setCards(updatedCards);
  };

  const handleLabelChange = (event, cardId) => {
    const updatedCards = cards.map((card) =>
      card.id === cardId ? { ...card, label: event.target.value } : card
    );
    setCards(updatedCards);
    handleSave(cardId, 'label', event.target.value);
  };

  const handleAddCard = async () => {
    if (newCardTitle.trim() === '' || newCardContent.trim() === '') {
      alert('Title and content cannot be empty.');
      return;
    }

    try {
      const response = await axios.post('http://localhost:5000/stamps', {
        email: userEmail,
        title: newCardTitle,
        content: newCardContent,
        label: newCardLabel,
      });
      const newCard = {
        id: response.data.id,
        title: newCardTitle,
        content: newCardContent,
        label: newCardLabel,
      };
      setCards([...cards, newCard]);
      setNewCardTitle('');
      setNewCardContent('');
      setNewCardLabel('none');
      setCurrentPage(Math.ceil((cards.length + 1) / cardsPerPage) - 1); // Go to the last page
    } catch (error) {
      console.error('Error adding card:', error);
      alert('There was an error adding the card. Please try again.');
    }
  };

  const handleZoom = (cardId) => {
    const cardToZoom = cards.find((card) => card.id === cardId);
    setZoomedCard(cardToZoom);
  };

  const handleCloseZoom = () => {
    setZoomedCard(null);
  };

  const handleNextPage = () => {
    setCurrentPage((prevPage) => prevPage + 1);
  };

  const handlePrevPage = () => {
    setCurrentPage((prevPage) => prevPage - 1);
  };

  const filteredCards = cards.filter((card) => {
    const matchesSearch = card.title.toLowerCase().includes(searchQuery.toLowerCase()) || card.content.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = labelFilter === 'all' || card.label === labelFilter;
    return matchesSearch && matchesFilter;
  });

  const paginatedCards = filteredCards.slice(currentPage * cardsPerPage, (currentPage + 1) * cardsPerPage);

  const containerStyle = {
    backgroundColor: '#e6f7ff',
    display: 'flex',
    flexWrap: 'wrap',
    gap: '20px',
    justifyContent: 'center',
    padding: '20px',
    alignItems: 'flex-start',
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
    borderRadius: '15px',
  };

  

  const cardStyle = (label) => ({
    backgroundColor: '#ffff99',
    border: `2px solid ${label === 'none' ? '#cccccc' : label}`,
    borderRadius: '8px',
    padding: '20px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.8)',
    backgroundImage: 'url("https://www.transparenttextures.com/patterns/notebook.png")',
    backgroundSize: 'cover',
    display: 'flex',
    flexDirection: 'column',
    gap: '10px',
    maxWidth: '300px',
    flex: '1 1 calc(33.33% - 40px)',
    boxSizing: 'border-box',
    margin: '10px',
  });

  const inputStyle = {
    backgroundColor: '#ffff99',
    fontSize: '1.2rem',
    fontWeight: 'bold',
    width: '100%',
    padding: '10px',
    border: 'none',
    borderRadius: '4px',
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
  };

  const textAreaStyle = {
    backgroundColor: '#ffff99',
    width: '100%',
    padding: '10px',
    border: 'none',
    borderRadius: '4px',
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
    minHeight: '100px',
    resize: 'vertical',
  };

  const selectStyle = {
    backgroundColor: '#ffff99',
    padding: '10px',
    borderRadius: '4px',
    border: 'none',
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
    width: '100%',
  };

  const filterStyle = {
    position: 'absolute',
    top: '20px',
    right: '20px',
    backgroundColor: '#ffff99',
    padding: '10px',
    borderRadius: '8px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    display: 'flex',
    alignItems: 'center',
    gap: '10px',
  };

  const labelFilterStyle = {
    marginBottom: '0',
  };

  const plusButtonStyle = {
    backgroundColor: '#ffff99',
    color: '#ffffff',
    alignSelf: 'flex-end',
    borderRadius: '50%',
    width: '40px',
    height: '40px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '0',
    border: 'none',
    backgroundImage: 'url(https://www.svgrepo.com/show/126731/zoom-in.svg)',
    backgroundSize: '100%',
    backgroundRepeat: 'no-repeat',
    backgroundPosition: 'center',
    cursor: 'zoom-in'
  };

  const zoomedCardStyle = {
    position: 'fixed',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: '80%',
    height: '80%',
    backgroundColor: '#ffff99',
    border: '2px dashed #cccccc',
    borderRadius: '8px',
    padding: '20px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.8)',
    backgroundImage: 'url("https://www.transparenttextures.com/patterns/notebook.png")',
    backgroundSize: 'cover',
    display: 'flex',
    flexDirection: 'column',
    gap: '10px',
    zIndex: 1000,
    boxSizing: 'border-box',
  };

  const buttonStyle = {
    padding: '8px 16px',
    borderRadius: '4px',
    border: 'none',
    cursor: 'pointer',
    transition: 'background-color 0.3s ease',
  };

  const deleteButtonStyle = {
    ...buttonStyle,
    backgroundColor: '#d9534f',
    color: '#ffffff',
    width: '70px',
    fontSize: '0.9rem'
  };

  const closeButtonStyle = {
    ...buttonStyle,
    backgroundColor: '#d9534f',
    color: '#ffffff',
    alignSelf: 'flex-end',
  };

  const addButtonStyle = {
    ...buttonStyle,
    backgroundColor: '#5cb85c',
    color: '#ffffff',
  };

  return (
    <div style={{ padding: '20px', flex: '1', backgroundColor: '#ffffff', overflowY: 'auto', position: 'relative' }}>
      <h1 style={{ marginBottom: '20px', textAlign: 'center', color: '#0088cc', fontFamily: "'Comic Sans MS', cursive, sans-serif" }}>Quick-Posts</h1>
      <div style={filterStyle}>
        <label htmlFor="labelFilter">Filter by label:</label>
        <select
          id="labelFilter"
          value={labelFilter}
          onChange={(e) => setLabelFilter(e.target.value)}
          style={labelFilterStyle}
        >
          <option value="all">All</option>
          <option value="none">None</option>
          <option value="red">Red</option>
          <option value="blue">Blue</option>
          <option value="green">Green</option>
        </select>
      </div>
      <div style={containerStyle}>
        {paginatedCards.map((card) => (
          <div key={card.id} style={cardStyle(card.label)}>
            <input
              style={inputStyle}
              type="text"
              value={card.title}
              onChange={(e) => handleTitleChange(e, card.id)}
              onBlur={() => handleSave(card.id, 'title', card.title)}
            />
            <textarea
              style={textAreaStyle}
              value={card.content}
              onChange={(e) => handleContentChange(e, card.id)}
              onBlur={() => handleSave(card.id, 'content', card.content)}
            />
            <select
              style={selectStyle}
              value={card.label}
              onChange={(e) => handleLabelChange(e, card.id)}
            >
              <option value="none">None</option>
              <option value="red">Red</option>
              <option value="blue">Blue</option>
              <option value="green">Green</option>
            </select>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '10px' }}>
            <button style={deleteButtonStyle} onClick={() => confirmDelete(card.id)}>
                Delete
              </button>
              <button style={plusButtonStyle} onClick={() => handleZoom(card.id)} />
            </div>
          </div>
        ))}
        <div style={cardStyle(newCardLabel)}>
          <input
            style={inputStyle}
            type="text"
            placeholder="New Card Title"
            value={newCardTitle}
            onChange={(e) => setNewCardTitle(e.target.value)}
          />
          <textarea
            style={textAreaStyle}
            placeholder="New Card Content"
            value={newCardContent}
            onChange={(e) => setNewCardContent(e.target.value)}
          />
          <select
            style={selectStyle}
            value={newCardLabel}
            onChange={(e) => setNewCardLabel(e.target.value)}
          >
            <option value="none">None</option>
            <option value="red">Red</option>
            <option value="blue">Blue</option>
            <option value="green">Green</option>
          </select>
          <button style={addButtonStyle} onClick={handleAddCard}>
            Add Card
          </button>
        </div>
      </div>
      <div style={{ marginTop: '20px', textAlign: 'center' }}>
      {currentPage > 0 && (
          <button style={buttonStyle} onClick={handlePrevPage}>
            Previous
          </button>
        )}
        {currentPage < Math.ceil(filteredCards.length / cardsPerPage) - 1 && (
          <button style={buttonStyle} onClick={handleNextPage}>
            Next
          </button>
        )}
      </div>
      {zoomedCard && (
        <div style={zoomedCardStyle}>
          <input
            type="text"
            value={zoomedCard.title}
            onChange={(e) => handleTitleChange(e, zoomedCard.id)}
            onBlur={(e) => handleSave(zoomedCard.id, 'title', e.target.value)}
            style={inputStyle}
          />
          <textarea
            value={zoomedCard.content}
            onChange={(e) => handleContentChange(e, zoomedCard.id)}
            onBlur={(e) => handleSave(zoomedCard.id, 'content', e.target.value)}
            style={{ ...textAreaStyle, height: 'calc(100% - 100px)' }}
          />
          <button style={closeButtonStyle} onClick={handleCloseZoom}>
            Close
          </button>
        </div>
      )}
      {cardToDelete && (
        <ConfirmDeleteDialog
          isOpen={true}
          onClose={handleCancelDelete}
          onConfirm={handleDelete}
        />
      )}
    </div>
  );
};

export default MainContent;
