import React from 'react';

const ConfirmDeleteDialog = ({ isOpen, onClose, onConfirm }) => {
  if (!isOpen) return null;

  const dialogStyle = {
    position: 'fixed',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    backgroundColor: '#fff',
    padding: '20px',
    borderRadius: '8px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
    zIndex: 1000,
  };

  const overlayStyle = {
    position: 'fixed',
    top: 0,
    left: 0,
    width: '100%',
    height: '100%',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    zIndex: 999,
  };

  return (
    <>
      <div style={overlayStyle} onClick={onClose}></div>
      <div style={dialogStyle}>
        <p>Are you sure you want to delete this card?</p>
        <button onClick={onConfirm} style={{ backgroundColor: 'red', color: 'white', border: 'none', padding: '10px', borderRadius: '4px', marginRight: '10px' }}>
          Confirm
        </button>
        <button onClick={onClose} style={{ backgroundColor: '#ccc', color: '#333', border: 'none', padding: '10px', borderRadius: '4px' }}>
          Cancel
        </button>
      </div>
    </>
  );
};

export default ConfirmDeleteDialog;
