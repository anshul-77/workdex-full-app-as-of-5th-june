import { createChatBotMessage } from 'react-chatbot-kit';

class ActionProvider {
  constructor(createChatBotMessage, setStateFunc, createClientMessage) {
    this.createChatBotMessage = createChatBotMessage;
    this.setState = setStateFunc;
    this.createClientMessage = createClientMessage;
  }

  handleGreeting = () => {
    const messages = [
      this.createChatBotMessage("Hello! How can I assist you today?"),
      this.createChatBotMessage("Hi there! Need help with something?"),
      this.createChatBotMessage("Hey! What can I do for you today?")
    ];
    this.setState((prev) => ({
      ...prev,
      messages: [...prev.messages, messages[Math.floor(Math.random() * messages.length)]],
    }));
  };

  handleCasual = () => {
    const messages = [
      this.createChatBotMessage("That's nice!"),
      this.createChatBotMessage("Great to hear!"),
      this.createChatBotMessage("Sounds good!")
    ];
    this.setState((prev) => ({
      ...prev,
      messages: [...prev.messages, messages[Math.floor(Math.random() * messages.length)]],
    }));
  };

  handleFarewell = () => {
    const messages = [
      this.createChatBotMessage("Goodbye! Have a nice day!"),
      this.createChatBotMessage("Bye! Take care!"),
      this.createChatBotMessage("See you! Have a great day!")
    ];
    this.setState((prev) => ({
      ...prev,
      messages: [...prev.messages, messages[Math.floor(Math.random() * messages.length)]],
    }));
  };

  handleAddStamps = () => {
    const message = this.createChatBotMessage(
      'To add a stamp, go to the main page and click on the "Add Stamp" button. Enter the details of the stamp and save it. You can edit or delete existing stamps by clicking on them.'
    );
    this.setState((prev) => ({
      ...prev,
      messages: [...prev.messages, message],
    }));
  };

  handleUpdateProfile = () => {
    const message = this.createChatBotMessage(
      'To update your profile, click on the profile icon in the top bar. You can edit your details and save the changes. There is also a "Log Out" option for signing out.'
    );
    this.setState((prev) => ({
      ...prev,
      messages: [...prev.messages, message],
    }));
  };

  handleLogOut = () => {
    const message = this.createChatBotMessage(
      'To log out, click on the profile icon in the top bar and select the "Log Out" option. This will sign you out of your account.'
    );
    this.setState((prev) => ({
      ...prev,
      messages: [...prev.messages, message],
    }));
  };

  handlePersonalCalendar = () => {
    const message = this.createChatBotMessage(
      'To manage your events, click on the calendar icon in the top bar. Add events to specific days, edit or delete them, and save the changes.'
    );
    this.setState((prev) => ({
      ...prev,
      messages: [...prev.messages, message],
    }));
  };

  handleWorkspace = () => {
    const message = this.createChatBotMessage(
      'In the workspace, create different boards like Trello. Inside each board, create lists with draggable cards. You can add, edit, or delete cards and move them between lists.'
    );
    this.setState((prev) => ({
      ...prev,
      messages: [...prev.messages, message],
    }));
  };

  handleReadingList = () => {
    const message = this.createChatBotMessage(
      'To manage your reading list, go to the personal zone in the sidebar. Add books to your list, save them, and use the "Suggest Book" feature for recommendations.'
    );
    this.setState((prev) => ({
      ...prev,
      messages: [...prev.messages, message],
    }));
  };

  handleTodoList = () => {
    const message = this.createChatBotMessage(
      'The Todo List allows you to manage tasks. Add lists, create draggable cards, edit or delete them, and move cards between lists.'
    );
    this.setState((prev) => ({
      ...prev,
      messages: [...prev.messages, message],
    }));
  };

  handlePersonal = () => {
    const messages = [
      this.createChatBotMessage("Sure! How can I assist you personally?"),
      this.createChatBotMessage("Personal requests? I'm here to help!"),
      this.createChatBotMessage("Let's talk about personalization. What do you need?")
    ];
    this.setState((prev) => ({
      ...prev,
      messages: [...prev.messages, messages[Math.floor(Math.random() * messages.length)]],
    }));
  };

  handleUnknown = () => {
    const messages = [
      this.createChatBotMessage("I'm sorry, I didn't understand that. Could you please rephrase?"),
      this.createChatBotMessage("Hmm, I didn't get that. Can you say it differently?"),
      this.createChatBotMessage("I’m not sure what you mean. Can you provide more details?")
    ];
    this.setState((prev) => ({
      ...prev,
      messages: [...prev.messages, messages[Math.floor(Math.random() * messages.length)]],
    }));
  };

  handleFrustration = () => {
    const messages = [
      this.createChatBotMessage("I can sense some frustration. Let me help!"),
      this.createChatBotMessage("I'm here to help, please let me know what’s wrong."),
      this.createChatBotMessage("It seems like you’re having a tough time. How can I assist?")
    ];
    this.setState((prev) => ({
      ...prev,
      messages: [...prev.messages, messages[Math.floor(Math.random() * messages.length)]],
    }));
  };

  handleAppreciation = () => {
    const messages = [
      this.createChatBotMessage("Thank you! I'm glad I could help."),
      this.createChatBotMessage("I appreciate your feedback!"),
      this.createChatBotMessage("That means a lot, thank you!")
    ];
    this.setState((prev) => ({
      ...prev,
      messages: [...prev.messages, messages[Math.floor(Math.random() * messages.length)]],
    }));
  };

  handleMisspelling(suggestions) {
    const suggestionMessage = `It looks like you might have misspelled "${suggestions[0]}". Did you mean: ${suggestions.join(', ')}?`;
    const message = this.createChatBotMessage(suggestionMessage);
    this.setState(prev => ({
      ...prev,
      messages: [...prev.messages, message]
    }));
  }
  
  handleGanttChart = () => {
    const message = this.createChatBotMessage(
      'The Gantt Chart helps you visualize project timelines and track task progress. Add tasks with start and end dates, update progress, and view dependencies to manage your projects efficiently.'
    );
    this.setState((prev) => ({
      ...prev,
      messages: [...prev.messages, message],
    }));
  };
  

  handleFeatures() {
    const message = this.createChatBotMessage(
      'The features include personal todo-list, Calender, Reading List, workspace with boards etc. For furthur information please try putting specific feature name..'
    );
    this.setState((prev) => ({
      ...prev,
      messages: [...prev.messages, message],
    }));
  }

}




export default ActionProvider;
