// src/botConfig.js
import { createChatBotMessage } from 'react-chatbot-kit';

const botName = 'TutorBot';

const botConfig = {
  botName: botName,
  initialMessages: [
    createChatBotMessage(`Hi! I'm ${botName}. I'm here to guide you through the features of this application.`),
  ],
  customStyles: {
    botMessageBox: {
      backgroundColor: '#376B7E',
      padding: '10px', // Ensure consistent padding
      borderRadius: '10px', // Ensure consistent border radius
    },
    chatButton: {
      backgroundColor: '#5ccc9d',
      color: '#ffffff',
      borderRadius: '10px',
      padding: '10px 20px',
    },
  },
};

export default botConfig;
