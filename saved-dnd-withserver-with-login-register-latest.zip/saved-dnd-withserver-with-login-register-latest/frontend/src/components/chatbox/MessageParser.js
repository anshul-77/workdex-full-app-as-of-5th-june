import didYouMean from 'didyoumean2';

class MessageParser {
  constructor(actionProvider) {
    this.actionProvider = actionProvider;
  }

  parse(message) {
    const lowerCaseMessage = message.toLowerCase();
    const keywords = [
      'hi', 'hello', 'hey',
      'nice', 'cool', 'great', 'awesome',
      'bye', 'goodbye', 'see you', 'take care',
      'add stamps', 'stamps', 'stamp',
      'update profile', 'profile', 'edit profile', 'change profile', 'modify profile',
      'log out', 'logout', 'sign out', 'signout',
      'personal calendar', 'calendar', 'events', 'manage calendar', 'schedule', 'add events', 'edit events',
      'workspace', 'boards', 'lists', 'trello', 'draggable cards', 'manage boards', 'create board', 'edit lists',
      'reading list', 'books', 'suggest book', 'manage reading list', 'add book', 'edit books',
      'todo list', 'tasks', 'manage tasks', 'add tasks', 'edit todo list',
      'personal', 'personalize', 'personalization', 'personalized',
      'frustrated', 'angry', 'upset', 'annoyed',
      'thank you', 'thanks', 'appreciate', 'good job','features','workdex','website features','website','gantt','gantt chart','chart'
    ];

    let foundKeyword = false;
    let suggestion = null;

    // Check for exact keyword match
    foundKeyword = keywords.some(keyword => lowerCaseMessage.includes(keyword));

    // If no exact match found, check for suggestion
    if (!foundKeyword) {
      suggestion = didYouMean(lowerCaseMessage, keywords);
      console.log('Suggestion:', suggestion); // Debug log for suggestion
    }

    if (foundKeyword) {
      if (lowerCaseMessage.includes('hi') || lowerCaseMessage.includes('hello') || lowerCaseMessage.includes('hey')) {
        this.actionProvider.handleGreeting();
      } else if (lowerCaseMessage.includes('nice') || lowerCaseMessage.includes('cool') || lowerCaseMessage.includes('great') || lowerCaseMessage.includes('awesome')) {
        this.actionProvider.handleCasual();
      } else if (lowerCaseMessage.includes('bye') || lowerCaseMessage.includes('goodbye') || lowerCaseMessage.includes('see you') || lowerCaseMessage.includes('take care')) {
        this.actionProvider.handleFarewell();
      } else if (lowerCaseMessage.includes('add stamps') || lowerCaseMessage.includes('stamps') || lowerCaseMessage.includes('stamp')) {
        this.actionProvider.handleAddStamps();
      } else if (lowerCaseMessage.includes('update profile') || lowerCaseMessage.includes('profile') || lowerCaseMessage.includes('edit profile') || lowerCaseMessage.includes('change profile') || lowerCaseMessage.includes('modify profile')) {
        this.actionProvider.handleUpdateProfile();
      } else if (lowerCaseMessage.includes('log out') || lowerCaseMessage.includes('logout') || lowerCaseMessage.includes('sign out') || lowerCaseMessage.includes('signout')) {
        this.actionProvider.handleLogOut();
      } else if (lowerCaseMessage.includes('personal calendar') || lowerCaseMessage.includes('calendar') || lowerCaseMessage.includes('events') || lowerCaseMessage.includes('manage calendar') || lowerCaseMessage.includes('schedule') || lowerCaseMessage.includes('add events') || lowerCaseMessage.includes('edit events')) {
        this.actionProvider.handlePersonalCalendar();
      } else if (lowerCaseMessage.includes('workspace') || lowerCaseMessage.includes('boards') || lowerCaseMessage.includes('lists') || lowerCaseMessage.includes('trello') || lowerCaseMessage.includes('draggable cards') || lowerCaseMessage.includes('manage boards') || lowerCaseMessage.includes('create board') || lowerCaseMessage.includes('edit lists')) {
        this.actionProvider.handleWorkspace();
      } else if (lowerCaseMessage.includes('reading list') || lowerCaseMessage.includes('books') || lowerCaseMessage.includes('suggest book') || lowerCaseMessage.includes('manage reading list') || lowerCaseMessage.includes('add book') || lowerCaseMessage.includes('edit books')) {
        this.actionProvider.handleReadingList();
      } else if (lowerCaseMessage.includes('todo list') || lowerCaseMessage.includes('tasks') || lowerCaseMessage.includes('manage tasks') || lowerCaseMessage.includes('add tasks') || lowerCaseMessage.includes('edit todo list')) {
        this.actionProvider.handleTodoList();
      } else if (lowerCaseMessage.includes('personal') || lowerCaseMessage.includes('personalize') || lowerCaseMessage.includes('personalization') || lowerCaseMessage.includes('personalized')) {
        this.actionProvider.handlePersonal();
      } else if (lowerCaseMessage.includes('frustrated') || lowerCaseMessage.includes('angry') || lowerCaseMessage.includes('upset') || lowerCaseMessage.includes('annoyed')) {
        this.actionProvider.handleFrustration();
      } else if (lowerCaseMessage.includes('thank you') || lowerCaseMessage.includes('thanks') || lowerCaseMessage.includes('appreciate') || lowerCaseMessage.includes('good job')) {
        this.actionProvider.handleAppreciation();
      } else if (lowerCaseMessage.includes('features') || lowerCaseMessage.includes('workdex') || lowerCaseMessage.includes('website features') || lowerCaseMessage.includes('website')) {
        this.actionProvider.handleFeatures();
      }
      else if (lowerCaseMessage.includes('gantt') || lowerCaseMessage.includes('gantt chart') || lowerCaseMessage.includes('chart')) {
        this.actionProvider.handleGanttChart();
      }
    } else if (suggestion) {
      // Ensure suggestion is an array
      if (!Array.isArray(suggestion)) {
        suggestion = [suggestion];
      }
      this.actionProvider.handleMisspelling(suggestion);
    } else {
      this.actionProvider.handleUnknown();
    }
  }
}

export default MessageParser;
