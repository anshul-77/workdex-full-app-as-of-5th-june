import React from 'react';
import Chatbot from 'react-chatbot-kit';
import 'react-chatbot-kit/build/main.css';
import { AiOutlineCloseCircle } from 'react-icons/ai'; // Import Close icon from react-icons

import ActionProvider from './ActionProvider';
import MessageParser from './MessageParser';
import botConfig from './botConfig';

const ChatbotComponent = ({ onClose }) => {
  const chatbotStyles = {
    container: {
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      position: 'fixed',
      bottom: '20px',
      left: '20px',
      zIndex: 1000, // Ensure it's above other content
      height: 'auto', // Adjust height as needed
    },
    chatBox: {
      position: 'relative', // Ensure relative positioning for absolute child elements
      width: '100%',
      maxWidth: '275px', // Set a max width for the chatbox
      boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
      borderRadius: '10px',
      overflow: 'hidden',
      fontFamily: "'Roboto', sans-serif",
      backgroundColor: '#ffffff', // White background for the chatbox
    },
    closeButton: {
      position: 'absolute',
      top: '10px',
      right: '10px',
      cursor: 'pointer',
      backgroundColor: 'transparent',
      border: 'none',
      outline: 'none',
      zIndex: 1001, // Ensure it's above the chatbox
    },
    messageContainer: {
      backgroundColor: '#ffffff',
      borderRadius: '10px',
      padding: '10px',
      marginBottom: '10px',
    },
    botMessage: {
      backgroundColor: '#376B7E',
      color: '#ffffff',
      padding: '10px',
      borderRadius: '10px',
      margin: '5px 0',
      width: 'fit-content', // Adjust the width to fit content
      maxWidth: '100%', // Ensure it does not exceed the chatbox width
    },
  };

  return (
    <div style={chatbotStyles.container}>
      <div style={chatbotStyles.chatBox}>
        <button onClick={onClose} style={chatbotStyles.closeButton}>
          <AiOutlineCloseCircle size={24} />
        </button>
        <Chatbot
          config={botConfig}
          messageParser={MessageParser}
          actionProvider={ActionProvider}
          customStyles={{
            botMessageBox: chatbotStyles.botMessage,
          }}
          messageContainerStyle={chatbotStyles.messageContainer}
        />
      </div>
    </div>
  );
};

export default ChatbotComponent;
