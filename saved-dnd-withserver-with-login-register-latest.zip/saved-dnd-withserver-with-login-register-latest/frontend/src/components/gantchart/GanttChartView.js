import React, { useEffect, useRef, useState } from 'react';
import Gantt from 'frappe-gantt';
import 'frappe-gantt/dist/frappe-gantt.css';

const GanttChartView = ({ tasks }) => {
  const ganttRef = useRef(null);
  const [viewMode, setViewMode] = useState('Month');
  const ganttInstance = useRef(null);

  useEffect(() => {
    if (tasks.length > 0) {
      const ganttTasks = tasks.map((task) => ({
        id: task.id.toString(),
        name: task.title,
        start: new Date(task.start_date),
        end: new Date(task.end_date),
        progress: task.progress,
        dependencies: '',
      }));

      const startDate = new Date(Math.min(...ganttTasks.map(task => task.start)));
      const endDate = new Date(Math.max(...ganttTasks.map(task => task.end)));
      const extendedStartDate = new Date(startDate);
      extendedStartDate.setMonth(extendedStartDate.getMonth() - 4);
      const extendedEndDate = new Date(endDate);
      extendedEndDate.setMonth(extendedEndDate.getMonth() + 4);

      if (ganttInstance.current) {
        ganttInstance.current.refresh(ganttTasks);
        ganttInstance.current.change_view_mode(viewMode);
      } else {
        ganttInstance.current = new Gantt(ganttRef.current, ganttTasks, {
          view_modes: ['Quarter Day', 'Half Day', 'Day', 'Week', 'Month'],
          date_format: 'YYYY-MM-DD',
          custom_popup_html: null,
          on_click: (task) => {
            console.log('Task clicked:', task);
          },
          on_date_change: (task, start, end) => {
            console.log('Date changed:', task, start, end);
          },
          on_progress_change: (task, progress) => {
            console.log('Progress changed:', task, progress);
          },
          on_view_change: (mode) => {
            console.log('View changed:', mode);
          },
          start_date: extendedStartDate,
          end_date: extendedEndDate,
        });
      }

      return () => {
        if (ganttInstance.current) {
          ganttInstance.current = null;
        }
      };
    }
  }, [tasks, viewMode]);

  useEffect(() => {
    if (ganttInstance.current) {
      ganttInstance.current.change_view_mode(viewMode);
    }
  }, [viewMode]);

  return (
    <div style={{ width: '100%' }}>
      <div style={{ marginBottom: '10px', textAlign: 'center' }}>
        <button
          style={buttonStyle}
          onClick={() => setViewMode('Quarter Day')}
        >
          Quarter Day
        </button>
        <button
          style={buttonStyle}
          onClick={() => setViewMode('Half Day')}
        >
          Half Day
        </button>
        <button
          style={buttonStyle}
          onClick={() => setViewMode('Day')}
        >
          Day
        </button>
        <button
          style={buttonStyle}
          onClick={() => setViewMode('Week')}
        >
          Week
        </button>
        <button
          style={buttonStyle}
          onClick={() => setViewMode('Month')}
        >
          Month
        </button>
      </div>
      <div style={{ overflowX: 'auto', overflowY: 'hidden', height: '500px' }}>
        <svg ref={ganttRef} style={{ minWidth: '4000px', height: '500px' }} />
      </div>
    </div>
  );
};

const buttonStyle = {
  backgroundColor: '#4CAF50', /* Green background */
  border: 'none', /* Remove borders */
  color: 'white', /* White text */
  padding: '8px 16px', /* Smaller padding */
  textAlign: 'center', /* Centered text */
  textDecoration: 'none', /* Remove underline */
  display: 'inline-block', /* Make it inline */
  fontSize: '14px', /* Slightly smaller font size */
  margin: '4px 8px', /* Reduced margin */
  cursor: 'pointer', /* Cursor on hover */
  borderRadius: '4px', /* Rounded corners */
};

export default GanttChartView;