import React from 'react';

const TaskList = ({ tasks }) => {
  const formatDate = (dateStr) => {
    const date = new Date(dateStr);
    return date.toISOString().slice(0, 10); // Convert to YYYY-MM-DD
  };

  return (
    <div>
      {tasks.map((task) => (
        <div key={task.id}>
          <h3>{task.title}</h3>
          <p>
            Start Date: {formatDate(task.start_date)} | End Date: {formatDate(task.end_date)} | Progress: {task.progress}%
          </p>
        </div>
      ))}
    </div>
  );
};

export default TaskList;
