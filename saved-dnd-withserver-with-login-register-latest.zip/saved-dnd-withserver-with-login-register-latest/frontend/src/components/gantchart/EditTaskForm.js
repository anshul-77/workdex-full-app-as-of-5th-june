// EditTaskForm.js
import React, { useState, useEffect } from 'react';

const EditTaskForm = ({ task, editTask, onCancelEdit }) => {
  const [title, setTitle] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (task) {
      setTitle(task.title);
      setStartDate(task.start_date);
      setEndDate(task.end_date);
      setProgress(task.progress);
    }
  }, [task]);

  const handleSubmit = (e) => {
    e.preventDefault();
    editTask(task.id, { title, start_date: startDate, end_date: endDate, progress });
  };

  return (
    <div>
      <h2>Edit Task</h2>
      <form onSubmit={handleSubmit}>
        <label>
          Title:
          <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} />
        </label>
        <br />
        <label>
          Start Date:
          <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
        </label>
        <br />
        <label>
          End Date:
          <input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} />
        </label>
        <br />
        <label>
          Progress:
          <input type="number" value={progress} onChange={(e) => setProgress(e.target.value)} />
        </label>
        <br />
        <button type="submit">Save</button>
        <button type="button" onClick={onCancelEdit}>Cancel</button>
      </form>
    </div>
  );
};

export default EditTaskForm;
