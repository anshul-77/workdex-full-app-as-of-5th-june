import React from 'react';
import { Pie } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import './PieChartModal.css'; // Ensure this file is created

ChartJS.register(ArcElement, Tooltip, Legend);

const PieChartModal = ({ data, onClose }) => {
  return (
    <div className="modal">
      <div className="modal-content">
        <button className="close-button" onClick={onClose}>
          &times;
        </button>
        <div className="chart-container">
          <Pie data={data} />
        </div>
      </div>
    </div>
  );
};

export default PieChartModal;
