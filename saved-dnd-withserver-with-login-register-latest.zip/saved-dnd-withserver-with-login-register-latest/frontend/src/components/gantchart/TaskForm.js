import React, { useState } from 'react';

const TaskForm = ({ addTask }) => {
  const [newTask, setNewTask] = useState({
    title: '',
    start_date: '',
    end_date: '',
    progress: 0
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setNewTask({ ...newTask, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    addTask(newTask);
    setNewTask({
      title: '',
      start_date: '',
      end_date: '',
      progress: 0
    });
  };

  const formContainerStyle = {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'column',
    margin: '20px 0',
  };

  const formStyle = {
    display: 'flex',
    flexDirection: 'column',
    gap: '10px',
    width: '300px',
    padding: '20px',
    border: '1px solid #ccc',
    borderRadius: '5px',
    boxShadow: '0 0 10px rgba(0, 0, 0, 0.1)',
    backgroundColor: 'rgba(0, 0, 0, 0.8)', // Black with reduced opacity
    color: '#fff', // White text color
  };

  const inputStyle = {
    padding: '10px',
    fontSize: '16px',
    borderRadius: '4px',
    border: '1px solid #ccc',
    backgroundColor: 'rgba(255, 255, 255, 0.1)', // White with reduced opacity for inputs
    color: '#fff', // White text color
  };

  const buttonStyle = {
    padding: '10px',
    fontSize: '16px',
    cursor: 'pointer',
    backgroundColor: '#28a745',
    color: '#fff',
    border: 'none',
    borderRadius: '4px'
  };

  return (
    <div style={formContainerStyle}>
      <form onSubmit={handleSubmit} style={formStyle}>
        <input
          type="text"
          name="title"
          value={newTask.title}
          onChange={handleChange}
          placeholder="Task Title"
          style={inputStyle}
        />
        <input
          type="date"
          name="start_date"
          value={newTask.start_date}
          onChange={handleChange}
          placeholder="Starting Date"
          style={inputStyle}
        />
        <input
          type="date"
          name="end_date"
          value={newTask.end_date}
          onChange={handleChange}
          placeholder="Ending Date"
          style={inputStyle}
        />
        <input
          type="number"
          name="progress"
          value={newTask.progress}
          onChange={handleChange}
          placeholder="Progress (%)"
          style={inputStyle}
        />
        <button type="submit" style={buttonStyle}>Add Task</button>
      </form>
    </div>
  );
};

export default TaskForm;
