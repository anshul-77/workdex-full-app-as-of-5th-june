import React from 'react';

const RandomBookPrompt = ({ suggestedBook, onClose }) => {
    return (
        <div style={styles.prompt}>
            <div style={styles.content}>
                <h2>Suggested Book</h2>
                <p><strong>Title:</strong> {suggestedBook.title}</p>
                <p><strong>Author:</strong> {suggestedBook.authors ? suggestedBook.authors.join(', ') : 'Unknown'}</p>
            </div>
            <button onClick={onClose} style={styles.closeButton}>Close</button>
        </div>
    );
};

const styles = {
    prompt: {
        position: 'fixed',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        backgroundColor: '#ffffff',
        padding: '20px',
        borderRadius: '10px',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
        zIndex: '1000',
    },
    content: {
        marginBottom: '10px',
    },
    closeButton: {
        padding: '10px 20px',
        backgroundColor: '#ff0000',
        color: '#ffffff',
        border: 'none',
        borderRadius: '4px',
        cursor: 'pointer',
    },
};

export default RandomBookPrompt;
