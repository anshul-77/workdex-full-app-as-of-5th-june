import React from 'react';

const InfoModal = ({ onClose }) => {
  const modalStyle = {
    position: 'fixed',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    backgroundColor: '#fff',
    padding: '20px',
    borderRadius: '8px',
    boxShadow: '0 2px 5px rgba(0,0,0,0.3)',
    zIndex: 1000,
    maxWidth: '400px',
    width: '100%',
  };

  const overlayStyle = {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    zIndex: 999,
  };

  const headerStyle = {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '20px',
  };

  const closeButtonStyle = {
    background: 'none',
    border: 'none',
    fontSize: '1.2em',
    cursor: 'pointer',
  };

  const contentStyle = {
    textAlign: 'left',
  };

  const buttonStyle = {
    backgroundColor: '#1e90ff',
    color: '#fff',
    border: 'none',
    borderRadius: '4px',
    padding: '10px 20px',
    cursor: 'pointer',
    display: 'block',
    margin: '20px auto 0',
  };

  return (
    <>
      <div style={overlayStyle} onClick={onClose}></div>
      <div style={modalStyle}>
        <div style={headerStyle}>
          <h2>To-Do List Information</h2>
          <button style={closeButtonStyle} onClick={onClose}>
            &times;
          </button>
        </div>
        <div style={contentStyle}>
          <p>
            Organize your tasks into three lists: <strong>To Do</strong>, <strong>In Progress</strong>, and <strong>Done</strong>.
          </p>
          <p>
            This helps you track your progress and manage your workload efficiently. Here are some general use cases:
          </p>
          <ul>
            <li>Plan your day by listing all tasks in the <strong>To Do</strong> list.</li>
            <li>Move tasks to <strong>In Progress</strong> as you start working on them.</li>
            <li>Once completed, move tasks to the <strong>Done</strong> list.</li>
          </ul>
        </div>
        <button style={buttonStyle} onClick={onClose}>
          Got it!
        </button>
      </div>
    </>
  );
};

export default InfoModal;
