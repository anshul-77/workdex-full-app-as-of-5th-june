import React from 'react';

const DeleteConfirmationModal = ({ itemName, onConfirm, onCancel }) => {
    return (
        <div style={styles.overlay}>
            <div style={styles.modal}>
                <h2>Confirm Deletion</h2>
                <p>Are you sure you want to delete "{itemName}"? This action cannot be undone.</p>
                <div style={styles.buttons}>
                    <button onClick={onConfirm} style={styles.confirmButton}>Yes</button>
                    <button onClick={onCancel} style={styles.cancelButton}>No</button>
                </div>
            </div>
        </div>
    );
};

const styles = {
    overlay: {
        position: 'fixed',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
    },
    modal: {
        backgroundColor: 'white',
        padding: '20px',
        borderRadius: '10px',
        boxShadow: '0 2px 10px rgba(0, 0, 0, 0.1)',
        textAlign: 'center',
    },
    buttons: {
        marginTop: '20px',
        display: 'flex',
        justifyContent: 'space-around',
    },
    confirmButton: {
        padding: '10px 20px',
        backgroundColor: '#f44336',
        color: 'white',
        border: 'none',
        borderRadius: '5px',
        cursor: 'pointer',
    },
    cancelButton: {
        padding: '10px 20px',
        backgroundColor: '#ddd',
        color: 'black',
        border: 'none',
        borderRadius: '5px',
        cursor: 'pointer',
    },
};

export default DeleteConfirmationModal;
