import React, { useState } from 'react';

const TodoList = () => {
  const [todoList, setTodoList] = useState([]);
  const [newTodo, setNewTodo] = useState('');

  const handleAddTodo = () => {
    if (newTodo.trim() !== '') {
      setTodoList([...todoList, newTodo]);
      setNewTodo('');
    }
  };

  const handleDeleteTodo = (index) => {
    const updatedList = todoList.filter((_, i) => i !== index);
    setTodoList(updatedList);
  };

  const sectionStyle = {
    padding: '20px',
    maxWidth: '400px',
    margin: '0 auto',
    border: '1px solid #ccc',
    borderRadius: '8px',
    backgroundColor: '#ffff99',
    borderRadius: '10px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
  };

  const titleStyle = {
    fontSize: '1.5rem',
    marginBottom: '20px',
    textAlign: 'center',
    color: '#333',
  };

  const inputGroupStyle = {
    display: 'flex',
    justifyContent: 'space-between',
    marginBottom: '20px',
  };

  const inputStyle = {
    flex: 1,
    padding: '10px',
    border: '1px solid #ddd',
    borderRadius: '4px',
    fontSize: '1rem',
    marginRight: '10px',
    boxShadow: 'inset 0 1px 3px rgba(0, 0, 0, 0.1)',
    backgroundColor: '#ffffcc'
  };

  const buttonStyle = {
    padding: '10px 20px',
    border: 'none',
    borderRadius: '4px',
    backgroundColor: '#28a745',
    color: 'white',
    cursor: 'pointer',
    fontSize: '1rem',
    transition: 'background-color 0.3s ease',
  };

  const buttonHoverStyle = {
    backgroundColor: '#218838',
  };

  const listStyle = {
    listStyleType: 'none',
    padding: '0',
    margin: '0',
  };

  const listItemStyle = {
    marginBottom: '5px',
    display: 'flex',
    alignItems: 'center',
    padding: '10px',
    backgroundColor: '#e6f7ff',
    border: '1px solid #ddd',
    borderRadius: '4px',
    boxShadow: '0 1px 3px rgba(0, 0, 0, 0.1)',
  };

  const todoTextStyle = {
    flex: 1,
  };

  const deleteButtonStyle = {
    padding: '5px 10px',
    border: 'none',
    borderRadius: '4px',
    backgroundColor: '#dc3545',
    color: 'white',
    cursor: 'pointer',
    fontSize: '0.9rem',
    marginLeft: '10px',
    transition: 'background-color 0.3s ease',
  };

  const deleteButtonHoverStyle = {
    backgroundColor: '#c82333',
  };

  return (
    <div style={sectionStyle}>
      <h2 style={titleStyle}>To-Do List</h2>
      <div style={inputGroupStyle}>
        <input
          type="text"
          placeholder="Add a new task"
          value={newTodo}
          onChange={(e) => setNewTodo(e.target.value)}
          style={inputStyle}
        />
        <button
          onClick={handleAddTodo}
          style={buttonStyle}
          onMouseOver={(e) => e.target.style.backgroundColor = buttonHoverStyle.backgroundColor}
          onMouseOut={(e) => e.target.style.backgroundColor = buttonStyle.backgroundColor}
        >
          Add Task
        </button>
      </div>
      <ul style={listStyle}>
        {todoList.map((todo, index) => (
          <li key={index} style={listItemStyle}>
            <span style={todoTextStyle}>{todo}</span>
            <button
              onClick={() => handleDeleteTodo(index)}
              style={deleteButtonStyle}
              onMouseOver={(e) => e.target.style.backgroundColor = deleteButtonHoverStyle.backgroundColor}
              onMouseOut={(e) => e.target.style.backgroundColor = deleteButtonStyle.backgroundColor}
            >
              Delete
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default TodoList;

