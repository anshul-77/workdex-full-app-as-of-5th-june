import React, { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../login/AuthContext';
import DeleteConfirmationModal from './DeleteConfirmationModal';
import RandomBookPrompt from './RandomBookPrompt'; // Assuming you have created this component

const ReadingList = ({ onClose }) => {
    const [items, setItems] = useState([]);
    const [newItem, setNewItem] = useState({ name: '', type: '', status: 'Yet to Start', author: '', date_of_completion: '' });
    const { userEmail } = useContext(AuthContext);
    const [showDeleteModal, setShowDeleteModal] = useState(false);
    const [itemToDelete, setItemToDelete] = useState(null);
    const [suggestedBook, setSuggestedBook] = useState(null);
    const [showRandomBookPrompt, setShowRandomBookPrompt] = useState(false); // State to manage showing the random book prompt

    useEffect(() => {
        fetchItems();
    }, []);

    const fetchItems = async () => {
        try {
            const res = await axios.get('http://localhost:5000/reading-list', { params: { email: userEmail } });
            setItems(res.data);
        } catch (err) {
            console.error(err.message);
        }
    };

    const handleChange = (index, e) => {
        const { name, value } = e.target;
        const updatedItems = items.map((item, i) => 
            i === index ? { ...item, [name]: value } : item
        );
        setItems(updatedItems);
    };

    const handleNewChange = (e) => {
        const { name, value } = e.target;
        setNewItem({ ...newItem, [name]: value });
    };

    const handleSave = async (index) => {
        const updatedItems = [...items];
        const itemToSave = updatedItems[index];
        itemToSave.email = userEmail;

        if (itemToSave.date_of_completion === '') {
            itemToSave.date_of_completion = null;
        }

        try {
            if (itemToSave.id) {
                await axios.put(`http://localhost:5000/reading-list/${itemToSave.id}`, itemToSave);
            } else {
                const res = await axios.post('http://localhost:5000/reading-list', itemToSave);
                updatedItems[index].id = res.data.id;
            }
            setItems(updatedItems);
        } catch (err) {
            console.error(err.message);
        }
    };

    const handleNewSave = async () => {
        const formData = { ...newItem, email: userEmail };
        if (formData.date_of_completion === '') {
            formData.date_of_completion = null;
        }

        try {
            const res = await axios.post('http://localhost:5000/reading-list', formData);
            formData.id = res.data.id;
            setItems([...items, formData]);
            setNewItem({ name: '', type: '', status: 'Yet to Start', author: '', date_of_completion: '' });
        } catch (err) {
            console.error(err.message);
        }
    };

    const handleDelete = (index) => {
        setItemToDelete(index);
        setShowDeleteModal(true);
    };

    const confirmDelete = async () => {
        const index = itemToDelete;
        const itemToDeleteData = items[index];

        if (itemToDeleteData.id) {
            try {
                await axios.delete(`http://localhost:5000/reading-list/${itemToDeleteData.id}`, { data: { email: userEmail } });
            } catch (err) {
                console.error(err.message);
            }
        }

        setItems(items.filter((_, i) => i !== index));
        setShowDeleteModal(false);
        setItemToDelete(null);
    };

    const cancelDelete = () => {
        setShowDeleteModal(false);
        setItemToDelete(null);
    };

    const handleSuggestBook = async () => {
        try {
            const res = await axios.get('http://localhost:5000/suggest-book');
            setSuggestedBook(res.data);
            setShowRandomBookPrompt(true); // Show the random book prompt when a book is suggested
        } catch (err) {
            console.error(err.message);
        }
    };

    const closeRandomBookPrompt = () => {
        setShowRandomBookPrompt(false); // Close the random book prompt
        setSuggestedBook(null); // Clear the suggested book data
    };

    return (
        <div style={styles.container}>
            <button onClick={onClose} style={styles.closeButton}>×</button>
            <h1 style={styles.heading}>Reading List</h1>
            <table style={styles.table}>
                <thead>
                    <tr>
                        <th style={styles.tableHeader}>Name</th>
                        <th style={styles.tableHeader}>Type</th>
                        <th style={styles.tableHeader}>Status</th>
                        <th style={styles.tableHeader}>Author</th>
                        <th style={styles.tableHeader}>Completed</th>
                        <th style={styles.tableHeader}>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {items.map((item, index) => (
                        <tr key={index} style={styles.tableRow}>
                            <td style={styles.tableCell}>
                                <input
                                    name="name"
                                    value={item.name}
                                    onChange={(e) => handleChange(index, e)}
                                    style={styles.input}
                                />
                            </td>
                            <td style={styles.tableCell}>
                                <input
                                    name="type"
                                    value={item.type}
                                    onChange={(e) => handleChange(index, e)}
                                    style={styles.input}
                                />
                            </td>
                            <td style={styles.tableCell}>
                                <select
                                    name="status"
                                    value={item.status}
                                    onChange={(e) => handleChange(index, e)}
                                    style={styles.select}
                                >
                                    <option value="Yet to Start">Yet to Start</option>
                                    <option value="In Progress">In Progress</option>
                                    <option value="Completed">Completed</option>
                                </select>
                            </td>
                            <td style={styles.tableCell}>
                                <input
                                    name="author"
                                    value={item.author}
                                    onChange={(e) => handleChange(index, e)}
                                    style={styles.input}
                                />
                            </td>
                            <td style={styles.tableCell}>
                                <input
                                    name="date_of_completion"
                                    type="date"
                                    value={item.date_of_completion ? new Date(item.date_of_completion).toISOString().substring(0, 10) : ''}
                                    onChange={(e) => handleChange(index, e)}
                                    style={styles.input}
                                />
                            </td>
                            <td style={styles.tableCell}>
                                <div style={styles.actions}>
                                    <button onClick={() => handleSave(index)} style={styles.saveButton}>Save</button>
                                    <button onClick={() => handleDelete(index)} style={styles.deleteButton}>×</button>
                                </div>
                            </td>
                        </tr>
                    ))}
                    <tr style={styles.tableRow}>
                        <td style={styles.tableCell}>
                            <input
                                name="name"
                                value={newItem.name}
                                onChange={handleNewChange}
                                placeholder="Book Name"
                                style={styles.input}
                            />
                        </td>
                        <td style={styles.tableCell}>
                            <input
                                name="type"
                                value={newItem.type}
                                onChange={handleNewChange}
                                placeholder="Type"
                                style={styles.input}
                            />
                        </td>
                        <td style={styles.tableCell}>
                            <select
                                name="status"
                                value={newItem.status}
                                onChange={handleNewChange}
                                style={styles.select}
                            >
                                <option value="Yet to Start">Yet to Start</option>
                                <option value="In Progress">In Progress</option>
                                <option value="Completed">Completed</option>
                            </select>
                        </td>
                        <td style={styles.tableCell}>
                            <input
                                name="author"
                                value={newItem.author}
                                onChange={handleNewChange}
                                placeholder="Author"
                                style={styles.input}
                            />
                        </td>
                        <td style={styles.tableCell}>
                            <input
                                name="date_of_completion"
                                type="date"
                                value={newItem.date_of_completion}
                                onChange={handleNewChange}
                                style={styles.input}
                            />
                        </td>
                        <td style={styles.tableCell}>
                            <button onClick={handleNewSave} style={styles.addButton}>Add</button>
                        </td>
                    </tr>
                </tbody>
            </table>
            <button onClick={handleSuggestBook} style={styles.suggestButton}>Suggest Me Something</button>
            {showRandomBookPrompt && suggestedBook && (
                <RandomBookPrompt suggestedBook={suggestedBook} onClose={closeRandomBookPrompt} />
            )}
            {showDeleteModal && (
                <DeleteConfirmationModal
                    itemName={items[itemToDelete]?.name}
                    onConfirm={confirmDelete}
                    onCancel={cancelDelete}
                />
            )}
        </div>
    );
};

const styles = {
    container: {
        position: 'relative',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        padding: '20px',
        backgroundColor: '#99ccff',
        minHeight: '80vh',
        width: '90%',
        maxWidth: '1100px',
        boxSizing: 'border-box',
        margin: '20px auto',
        borderRadius: '20px',
        boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
    },
    closeButton: {
        position: 'absolute',
        top: '10px',
        right: '10px',
        background: 'transparent',
        border: 'none',
        fontSize: '20px',
        cursor: 'pointer',
        color: '#000',
    },
    heading: {
        textAlign: 'center',
        marginBottom: '20px',
        color: 'black',
        fontFamily: 'cursive',
        fontSize: '2em',
    },
    table: {
        width: '100%',
        borderCollapse: 'collapse',
        backgroundColor: 'rgba(0, 0, 0, 0.6)',
        borderRadius: '10px',
        overflow: 'hidden',
        marginBottom: '20px',
    },
    tableHeader: {
        padding: '10px',
        borderBottom: '2px solid #ccc',
        textAlign: 'left',
        backgroundColor: 'rgba(0, 204, 136, 0.8)',
        color: '#fff',
    },
    tableRow: {
        animation: 'fadeIn 0.5s',
    },
    tableCell: {
        padding: '10px',
        borderBottom: '1px solid #ccc',
    },
    input: {
        width: '100%',
        padding: '8px',
        boxSizing: 'border-box',
        border: '1px solid #ccc',
        borderRadius: '4px',
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        color: '#fff',
    },
    select: {
        width: '100%',
        padding: '8px',
        boxSizing: 'border-box',
        border: '1px solid #ccc',
        borderRadius: '4px',
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        color: '#fff',
    },
    actions: {
        display: 'flex',
        justifyContent: 'space-between',
        gap: '10px',
    },
    saveButton: {
        padding: '4px 8px',
        backgroundColor: '#4CAF50',
        color: '#fff',
        border: 'none',
        borderRadius: '4px',
        cursor: 'pointer',
        transition: 'background-color 0.3s',
    },
    deleteButton: {
        padding: '4px 8px',
        backgroundColor: 'transparent',
        color: '#f44336',
        border: 'none',
        borderRadius: '4px',
        cursor: 'pointer',
        fontSize: '16px',
    },
    addButton: {
        padding: '8px 16px',
        backgroundColor: '#008CBA',
        color: '#fff',
        border: 'none',
        borderRadius: '4px',
        cursor: 'pointer',
        transition: 'background-color 0.3s',
    },
    suggestButton: {
        padding: '10px 20px',
        backgroundColor: '#ff9900',
        color: '#fff',
        border: 'none',
        borderRadius: '4px',
        cursor: 'pointer',
        transition: 'background-color 0.3s',
        marginTop: '20px',
    },
    suggestionBox: {
        marginTop: '20px',
        padding: '20px',
        backgroundColor: '#f0f0f0',
        borderRadius: '10px',
        boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
        textAlign: 'center',
    },
};

export default ReadingList;
