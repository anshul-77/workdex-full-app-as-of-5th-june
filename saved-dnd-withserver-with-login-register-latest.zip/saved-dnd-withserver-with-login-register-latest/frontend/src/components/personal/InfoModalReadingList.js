import React from 'react';

const InfoModalReadingList = ({ onClose }) => {
  const modalStyle = {
    position: 'fixed',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    backgroundColor: '#fff',
    padding: '20px',
    borderRadius: '8px',
    boxShadow: '0 2px 5px rgba(0,0,0,0.3)',
    zIndex: 1000,
    maxWidth: '400px',
    width: '100%',
  };

  const overlayStyle = {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    zIndex: 999,
  };

  const headerStyle = {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '20px',
  };

  const closeButtonStyle = {
    background: 'none',
    border: 'none',
    fontSize: '1.2em',
    cursor: 'pointer',
  };

  const contentStyle = {
    textAlign: 'left',
  };

  const buttonStyle = {
    backgroundColor: '#1e90ff',
    color: '#fff',
    border: 'none',
    borderRadius: '4px',
    padding: '10px 20px',
    cursor: 'pointer',
    display: 'block',
    margin: '20px auto 0',
  };

  return (
    <>
      <div style={overlayStyle} onClick={onClose}></div>
      <div style={modalStyle}>
        <div style={headerStyle}>
          <h2>Reading List Information</h2>
          <button style={closeButtonStyle} onClick={onClose}>
            &times;
          </button>
        </div>
        <div style={contentStyle}>
          <p>
            Keep track of all the articles, books, and other content you want to read with our reading list feature. Organize your reading materials and never lose track of what you plan to read.
          </p>
          <p>
            Here are some general use cases:
          </p>
          <ul>
            <li>Add articles, books, and other reading materials to your list.</li>
            <li>Mark items as read or unread.</li>
            <li>Categorize your reading materials with tags or categories.</li>
            <li>Set reminders for important reading deadlines.</li>
            <li>Keep notes and thoughts about what you've read.</li>
          </ul>
        </div>
        <button style={buttonStyle} onClick={onClose}>
          Got it!
        </button>
      </div>
    </>
  );
};

export default InfoModalReadingList;
