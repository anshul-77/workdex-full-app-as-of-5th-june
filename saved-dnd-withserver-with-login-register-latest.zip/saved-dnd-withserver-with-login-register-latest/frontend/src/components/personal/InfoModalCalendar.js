import React from 'react';

const InfoModal = ({ onClose }) => {
  const modalStyle = {
    position: 'fixed',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    backgroundColor: '#fff',
    padding: '20px',
    borderRadius: '8px',
    boxShadow: '0 2px 5px rgba(0,0,0,0.3)',
    zIndex: 1000,
    maxWidth: '400px',
    width: '100%',
  };

  const overlayStyle = {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    zIndex: 999,
  };

  const headerStyle = {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '20px',
  };

  const closeButtonStyle = {
    background: 'none',
    border: 'none',
    fontSize: '1.2em',
    cursor: 'pointer',
  };

  const contentStyle = {
    textAlign: 'left',
  };

  const buttonStyle = {
    backgroundColor: '#1e90ff',
    color: '#fff',
    border: 'none',
    borderRadius: '4px',
    padding: '10px 20px',
    cursor: 'pointer',
    display: 'block',
    margin: '20px auto 0',
  };

  return (
    <>
      <div style={overlayStyle} onClick={onClose}></div>
      <div style={modalStyle}>
        <div style={headerStyle}>
          <h2>Personal Calendar Information</h2>
          <button style={closeButtonStyle} onClick={onClose}>
            &times;
          </button>
        </div>
        <div style={contentStyle}>
          <p>
            Our personal calendar feature allows you to add events to specific dates and maintain a track of your events. This ensures that you never miss an important date and can plan your activities effectively.
          </p>
          <p>
            Here are some general use cases:
          </p>
          <ul>
            <li>Add events like meetings, appointments, and deadlines to specific dates.</li>
            <li>View all your events in a monthly or weekly calendar view.</li>
            <li>Set reminders for important events to stay on track.</li>
            <li>Organize your schedule and manage your time efficiently.</li>
          </ul>
        </div>
        <button style={buttonStyle} onClick={onClose}>
          Got it!
        </button>
      </div>
    </>
  );
};
export default InfoModal;
