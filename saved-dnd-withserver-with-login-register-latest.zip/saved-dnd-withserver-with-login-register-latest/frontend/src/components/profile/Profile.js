import React, { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../login/AuthContext';

const LoginDetails = () => {
  const { userEmail } = useContext(AuthContext);
  const [loginDetails, setLoginDetails] = useState(null);
  const [profileExists, setProfileExists] = useState(false);
  const [profileData, setProfileData] = useState({
    name: '',
    email: userEmail,
    phone: '',
    age: '',
    profile_pic: ''
  });
  const [successMessage, setSuccessMessage] = useState('');

  useEffect(() => {
    if (userEmail) {
      axios.get(`http://localhost:5000/login-details/${userEmail}`)
        .then(response => {
          setLoginDetails(response.data);
        })
        .catch(error => console.error('There was an error fetching the login details!', error));

      axios.get(`http://localhost:5000/profile/${userEmail}`)
        .then(response => {
          if (response.data) {
            setProfileExists(true);
            setProfileData(response.data);
          }
        })
        .catch(error => console.error('There was an error checking the profile existence!', error));
    }
  }, [userEmail]);

  const handleChange = (e) => {
    setProfileData({
      ...profileData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const url = profileExists ? `http://localhost:5000/profiles/${userEmail}` : 'http://localhost:5000/profiles';
    const method = profileExists ? 'put' : 'post';

    axios({ method, url, data: profileData })
      .then(response => {
        setSuccessMessage('Profile updated successfully!');
        setTimeout(() => setSuccessMessage(''), 3000); // Clear message after 3 seconds
      })
      .catch(error => console.error('There was an error saving the profile!', error));
  };

  const styles = {
    container: {
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      height: '100vh',
      fontFamily: 'Arial, sans-serif',
      color: '#333',
      textAlign: 'center',
      flexDirection: 'column',
      padding: '20px'
    },
    content: {
      display: 'flex',
      gap: '40px',
      flexWrap: 'wrap',
      justifyContent: 'center'
    },
    title: {
      fontSize: '2.5em',
      marginBottom: '30px',
    },
    detailsCard: {
      border: '1px solid #ddd',
      borderRadius: '12px',
      padding: '30px',
      width: '350px',
      boxShadow: '0 4px 10px rgba(0, 0, 0, 0.1)',
      backgroundColor: '#fff',
      marginBottom: '30px',
      textAlign: 'left',
      flexShrink: '0',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center'
    },
    detailItem: {
      marginBottom: '20px',  // Increase margin bottom for more spacing
      fontSize: '1.2em',
    },
    firstDetailItem: {
      marginTop: '20px',  // Increase margin top for the first detail item
      marginBottom: '20px',
      fontSize: '1.2em',
    },
    profilePic: {
      width: '100px',
      height: '100px',
      borderRadius: '50%',
      marginBottom: '20px',
      objectFit: 'cover'
    },
    form: {
      border: '1px solid #ddd',
      borderRadius: '12px',
      padding: '30px',
      width: '350px',
      boxShadow: '0 4px 10px rgba(0, 0, 0, 0.1)',
      backgroundColor: '#fff',
      flexShrink: '0',
      textAlign: 'left',
      boxSizing: 'border-box'
    },
    formTitle: {
      fontSize: '1.8em',
      marginBottom: '20px'
    },
    input: {
      width: '100%',
      padding: '12px',
      margin: '10px 0',
      borderRadius: '6px',
      border: '1px solid #ccc',
      boxSizing: 'border-box',
      fontSize: '1em'
    },
    button: {
      padding: '12px 20px',
      borderRadius: '6px',
      border: 'none',
      backgroundColor: '#28a745',
      color: '#fff',
      cursor: 'pointer',
      fontSize: '1em',
      width: '100%',
      boxSizing: 'border-box'
    },
    successMessage: {
      backgroundColor: '#d4edda',
      color: '#155724',
      border: '1px solid #c3e6cb',
      borderRadius: '8px',
      padding: '10px',
      margin: '20px 0',
      fontSize: '1em',
      width: '100%',
      textAlign: 'center',
      boxSizing: 'border-box'
    }
  };

  return (
    <div style={styles.container}>
      <h2 style={styles.title}>Login and Profile Details</h2>
      <div style={styles.content}>
        {loginDetails ? (
          <div style={styles.detailsCard}>
            {profileData.profile_pic && <img src={profileData.profile_pic} alt="Profile" style={styles.profilePic} />}
            <h3>Login Details</h3>
            <div style={styles.firstDetailItem}>
              <span style={styles.detailLabel}>Name:</span> {loginDetails.name}
            </div>
            <div style={styles.detailItem}>
              <span style={styles.detailLabel}>Email:</span> {loginDetails.email}
            </div>
          </div>
        ) : (
          <p>Loading login details...</p>
        )}

        <div style={styles.form}>
          <h3 style={styles.formTitle}>{profileExists ? 'Update Profile' : 'Add New Profile'}</h3>
          {successMessage && <div style={styles.successMessage}>{successMessage}</div>}
          <form onSubmit={handleSubmit}>
            <input
              style={styles.input}
              type="text"
              name="name"
              placeholder="Name"
              value={profileData.name}
              onChange={handleChange}
              required
            />
            <input
              style={styles.input}
              type="email"
              name="email"
              placeholder="Email"
              value={profileData.email}
              readOnly
              required
            />
            <input
              style={styles.input}
              type="text"
              name="phone"
              placeholder="Phone"
              value={profileData.phone}
              onChange={handleChange}
            />
            <input
              style={styles.input}
              type="number"
              name="age"
              placeholder="Age"
              value={profileData.age}
              onChange={handleChange}
            />
            <input
              style={styles.input}
              type="text"
              name="profile_pic"
              placeholder="Profile Picture URL"
              value={profileData.profile_pic}
              onChange={handleChange}
            />
            <button style={styles.button} type="submit">{profileExists ? 'Update Profile' : 'Add Profile'}</button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default LoginDetails;
